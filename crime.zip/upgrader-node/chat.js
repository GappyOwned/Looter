'use strict';

require( "console-stamp" )( console, { pattern : "HH:MM:ss.l dd/mm/yyyy" });

let config = {
    'web': {
        'port': 8001,
        'host': '127.0.0.1',
    },
    'io': {
        'port': 57000,
        'host': '127.0.0.1',
    },
};

///////////////////////////////////////////////////////////////////////////////////////////////////////

let express = require('express');
let basicAuth = require('basic-auth-connect');
let bodyParser = require('body-parser');

let http = require('http');
let io_server = require('socket.io');

let cookie_reader = require('cookie');
let request = require('request');

let redis = require("redis");


///////////////////////////////////
function Cache() {
    this.cache = null;
    this._local_cache = {};
    this.list_action_remove_on_new_round = new Set([]);
    this.list_auth_actions = new Set([]);
    this.list_not_auth_actions = new Set(['bulk_chat', 'bulk_spin']);
    this.on_loaded = function () {};
}

Cache.prototype.connect = function() {
    let self = this;
    self.cache = redis.createClient({
        //path: '/var/run/redis/redis.sock',
        host: '127.0.0.1',
        port: 6379,
        db: 2,  //ta sama baza co z sesjami w django
    });

    self.cache.on("error", function (e) {
        console.error(e.toString());
        throw e;
    });

    self.cache.get('init_ws', function(err, reply) {
        if(null !== reply) {
            self._local_cache = JSON.parse(reply);
        }
        self.on_loaded();
    });
};

Cache.prototype.set = function(name, data) {
    if(this.cache === null) {
        return;
    }
    //niektore eventy musza byc czyszczone co nowa runde:)
    if(name === 'new_round') {
        for(let r_name of this.list_action_remove_on_new_round) {
            delete this._local_cache[r_name];
        }
        return;
    }

    this._local_cache[name] = data;
    this.cache.set('init_ws', JSON.stringify(this._local_cache));
};

Cache.prototype.get = function(name, default_) {
    default_ = default_ || null;
    if(this.cache === null) {
        return default_;
    }

    if(name in this._local_cache) {
        return this._local_cache[name];
    }
    return default_;
};

Cache.prototype.get_iter_all = function*(is_auth) {
    if(this.cache === null) {
        return;
    }
    if(!is_auth) {
        //yield ['new_round', {}];
    }

    for(let channel in this._local_cache) {
        if(!this._local_cache.hasOwnProperty(channel)) {
            continue;
        }

        if(is_auth) {
            if(!this.list_auth_actions.has(channel)) {
                continue;
            }
        }
        else {
            if(!this.list_not_auth_actions.has(channel)) {
                continue;
            }
        }

        yield [channel, this._local_cache[channel]];
    }
};


let global_cache = new Cache();
global_cache.connect();

///////////////////////////////////

let last_chat_messages = [];
let last_spins = [];

global_cache.on_loaded = function () {
    last_chat_messages = global_cache.get('bulk_chat', []);
    last_spins = global_cache.get('bulk_spin', []);
};

function Client(manager, socket, session_id, client_ip, client_id, client_data) {
    this.manager = manager;
    this.socket = socket;
    this.session_id = session_id;
    this.client_ip = client_ip;
    this.client_id = client_id;
    this.client_data = client_data;
}

Client.prototype.on_connect = function() {
    console.log('on_connect client ,client_ip=', this.client_ip, ',client_id=', this.client_id, ',client_data=', JSON.stringify(this.client_data));

    let socket = this.socket;
    socket['session_id'] = this.session_id;
    socket['steam_id'] = this.client_data.steam_id;
    socket['username'] = this.client_data.username;
    socket['user_id'] = this.client_data.user_id;
    socket['avatar'] = this.client_data.avatar;
    socket['admin'] = ( this.client_data.role == 2 || this.client_data.role == 3 ) ? true : false;
    socket['role'] = this.client_data.role;
    socket['can_access_chat'] = this.client_data.can_access_chat;
    socket['last_msg'] = 0;

    this.init_chat();
};

Client.prototype.on_disconnect = function() {

};

Client.prototype.emit = function(channel, data) {
    this.socket.emit(channel, data);
};

Client.prototype._build_message_chat = function(user_data, message) {
    let time = new Date();
    let hours = time.getHours(); if(hours <= 9) { hours = '0' + String(hours); }
    let minutes = time.getMinutes(); if(minutes <= 9) { minutes = '0' + String(minutes); }
    let seconds = time.getSeconds(); if(seconds <= 9) { seconds = '0' + String(seconds); }
    let time_str = hours + ':' + minutes; // + ':' + seconds;

    let _form = {
        'message_id': String(Date.now()),
        'user': user_data,
        'message': message,
        'created': time_str,
    };
    last_chat_messages.push(_form);

    let _end = last_chat_messages.length;
    let _begin = _end - 15;
    if(_begin < 0) {
        _begin = 0;
    }
    last_chat_messages = last_chat_messages.slice(_begin, _end);

    global_cache.set('bulk_chat', last_chat_messages);
    return _form;
};

Client.prototype.on_ban_chat = function() {
    console.log('on_ban_chat');
    this.socket['can_access_chat'] = false;
    this.socket.can_access_chat = false;
};

Client.prototype.init_chat = function() {
    let self = this;
    let socket = self.socket;

    socket.on('chat_send', function(message) {
        //console.log('on chat_send, ', message);

        if(socket.user_id == null) {
            return;
        }

        if(!socket.can_access_chat) {
            return;
        }

        let msg = message.replace( /[><]/g, "");

        if(socket.admin !== true) {
           let re = new RegExp("((?:[a-zA-Z0-9-]+)[^a-z0-9]+(?:com|pl|eu|gl|io|xyz|net|org|ru|gg|club))");
            if(re.test(msg)) {
                return;
            }
        }

        if( !msg.length ) {
            return;
        }

        if(socket.admin === true) {
            if(msg === '/reload') {
                return self.manager.emit('reload', true);
            }
        }

        if( Math.floor( Date.now() / 1000 ) - socket.last_msg <= 2 ) {
            return self.emit( 'chat_result', 'Stop spam...' );
        }

        socket[ 'last_msg' ] = Math.floor( Date.now() / 1000 );

        let _chat_dict = self._build_message_chat({
            user_id : socket.user_id,
            username : socket.username,
            avatar : socket.avatar,
            role : socket.role,
        }, msg);
        self.manager.emit('chat', _chat_dict);
    });
};


////////////////////////////////////////////////////////////////////////////////////////


function Manager(io_host, io_port) {
    this.server_http = http.createServer().listen(io_port, io_host);
    this.server_socket = io_server.listen(this.server_http);
    this.server_socket.set('transports', ['websocket']);

    this.clients = new Set();
    this._list_clients_by_steam_id = [];

    this._init();
}

Manager.prototype._init = function() {
    let self = this;

    self.server_socket.on('connection', function (socket) {
        let ip = self.get_ip(socket);
        if(ip === '51.255.85.92' || ip === '127.0.0.1') {  //manager laczy sie i emituje wiadomosci o trade
            console.log('bot manager was connected!');

            socket.on('message', function(data) {
                console.log('bot receive:', JSON.stringify(data));
                if(data['group'] == null) {
                    global_cache.set(data['channel'], data['data']);
                    self.emit(data['channel'], data['data']);

                    if(data['channel'] == 'spin') {
                        last_spins.push(data['data']);

                        let _end = last_spins.length;
                        let _begin = _end - 15;
                        if(_begin < 0) {
                            _begin = 0;
                        }
                        last_spins = last_spins.slice(_begin, _end);
                        global_cache.set('bulk_spin', last_spins);
                    }
                }
                else {
                    self.emit_to(data['group'], data['channel'], data['data']);
                }
            });
        }
        else {
            self.on_socket_connect(socket, ip);
        }
    });

    self.global_tasks();
};

Manager.prototype.emit = function(channel, data) {
    this.server_socket.emit(channel, data);
};

Manager.prototype.emit_to = function(target, channel, data) {
    this.server_socket.to(target).emit(channel, data);
};

Manager.prototype.get_ip = function(socket) {
    let remote_ip = socket.handshake.headers['x-forwarded-for'] || socket.request.connection.remoteAddress;
    remote_ip = String(remote_ip);

    return remote_ip.split(', ', 1)[0];
};

Manager.prototype.get_session = function(socket) {
    let cookies = socket.handshake.headers['cookie'] || '';
    let cookies_parsed = cookie_reader.parse(cookies);
    return cookies_parsed['sessionid'];
};

Manager.prototype.is_user_auth = function(socket, on_success, on_error) {
    let session_id = this.get_session(socket);

    function callback(err, reply) {
        if(null !== reply) {
            let s = (new Buffer(reply, 'base64')).toString().split(':');
            s.shift();
            let json = JSON.parse(s.join(':'));

            if(json['_auth_user_id'] === undefined) {
                console.log('is_user_auth failed:', s);
                on_error();
            }
            else {
                console.log('is_user_auth ok:', json);
                on_success(session_id, json);
            }
        }
        else {
            on_error();
        }
    }

    global_cache.cache.get('session:' + session_id, callback);
};

Manager.prototype.on_socket_connect = function(socket, ip) {
    socket.emit('users_online', {
        'count': (new Set(this._list_clients_by_steam_id)).size,
    });

    for(let channel_data of global_cache.get_iter_all(false)) {
        socket.emit(channel_data[0], channel_data[1]);
    }

    let self = this;
    let is_disconnected = false;  //zapobiega przed race condition..

    socket.on('disconnect', function() {
        is_disconnected = true;
        self.on_disconnect(socket, ip);
    });

    self.is_user_auth(socket, function (session_id, info) {
        if(!is_disconnected) {
            self.on_authorized(socket, ip, session_id, info);
        }
    }, function () {
        if(!is_disconnected) {
            self.on_not_authorized(socket, ip);
        }
    });
};

Manager.prototype.on_authorized = function(socket, ip, session_id, client_data) {
    for(let channel_data of global_cache.get_iter_all(true)) {
        socket.emit(channel_data[0], channel_data[1]);
    }

    let client_id = client_data['steam_id'];

    socket.join(client_id);
    socket.emit('system_auth', true);

    //manager, socket, session_id, client_ip, client_id, client_data
    let client = new Client(
        this,
        socket,
        session_id,
        ip,
        client_id,
        client_data
    );
    client.on_connect();

    this.clients.add(client);
    this._list_clients_by_steam_id.push(client.client_id);

    socket['_client'] = client;
};

Manager.prototype.on_not_authorized = function(socket, ip) {
    socket.emit('system_auth', false);
};

Manager.prototype.on_disconnect = function(socket, ip) {
    if(socket['_client'] !== undefined) {
        let client = socket['_client'];
        client.on_disconnect();

        this.clients.delete(client);

        let index = this._list_clients_by_steam_id.indexOf(client.client_id);
        if(index > -1) {
            this._list_clients_by_steam_id.splice(index, 1);
        }
    }
};

Manager.prototype.global_tasks = function () {
    let self = this;
    setInterval(function() {
        self.emit('users_online', {
            'count': (new Set(self._list_clients_by_steam_id)).size,
        });
    }, 10000); //10s
};

Manager.prototype.on_internal_channel = function (channel, data) {
    if(channel === 'user_ban') {
        //ban user in class, he cant send new messages
        for(let client of this.clients) {
            if(client.client_id === data['user_id']) {
                client.on_ban_chat();
            }
        }

        if(data['is_remove_all']) {
            //remove in db
            let new_messages = [];
            for(let i=0; i<last_chat_messages.length; i++) {
                let message_obj = last_chat_messages[i];
                if(message_obj['user']['user_id'] !== data['user_id']) {
                    new_messages.push(message_obj);
                }
            }
            last_chat_messages = new_messages;
            global_cache.set('bulk_chat', last_chat_messages);

            //emit do users
            this.emit('chat_user_remove', {
                'user_id': data['user_id'],
            });
        }
    }
    else if(channel === 'remove_msg') {
        //remove in db
        let new_messages = [];
        for(let i=0; i<last_chat_messages.length; i++) {
            let message_obj = last_chat_messages[i];
            if(message_obj['message_id'] !== data['message_id']) {
                new_messages.push(message_obj);
            }
        }
        last_chat_messages = new_messages;
        global_cache.set('bulk_chat', last_chat_messages);

        //emit do users
        this.emit('chat_msg_remove', {
            'message_id': data['message_id'],
        });
    }
    else {
        //
    }
};

////////////////////////////////////////////////////////////////////////////////////////


function Web(manager, web_host, web_port) {
    this.manager = manager;
    this._app = express();

    this.web_host = web_host;
    this.web_port = (web_port == null)? 8000: web_port;
    this._init();
}

Web.prototype.get_ip = function(req) {
    let remote_ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    remote_ip = String(remote_ip);

    return remote_ip.split(', ', 1)[0];
};

Web.prototype._init = function() {
    console.log('starting web');
    this._app.listen(this.web_port, this.web_host);

    this._app.use(bodyParser.json());
    this._app.use(bodyParser.urlencoded({ extended: true }));

    let self = this;
    let secure = function(req, res) {
        let ip = self.get_ip(req);
        console.log('web request ip=', ip);

        if(ip === '127.0.0.1' || ip === '::ffff:127.0.0.1') {
            return true;
        }

        res.setHeader('Content-Type', 'text/plain');
        res.status(403);
        res.send('Not authorized');
        return false;
    };

    this._app.post('/api/v1/emit_to/:target/:channel', function(req, res) {
        if(!secure(req, res)) { return; }
        self.on_emit(req, res);
    });
};

Web.prototype.on_emit = function(req, res) {
    let target = req.params['target'];
    let channel = req.params['channel'];
    let data = req.body;

    if(target === 'all') {
        this.manager.emit(channel, data);
    }
    else if(target === 'internal') {
        this.manager.on_internal_channel(channel, data);
    }
    else {
        this.manager.emit_to(target, channel, data);
    }

    res.setHeader('Content-Type', 'text/plain');
    res.status(200);
    res.send('OK');
};

////////////////////////////////////////////////////////////////////////////////////////

let manager = new Manager(config['io']['host'], config['io']['port']);
let web = new Web(manager, config['web']['host'], config['web']['port']);
