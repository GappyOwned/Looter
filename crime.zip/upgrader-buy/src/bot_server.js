'use strict';

require( "console-stamp" )( console, { pattern : "HH:MM:ss.l dd/mm/yyyy" });

let config = {
    'redis': {
        //path: '/var/run/redis/redis.sock',
        'host': 'redis',
        'port': 6379,
        'db': 1,
    },
    //optional:
    'web': {
        'port': 8002,
        //'basic_auth': {
        //    'username': 'iam_wizard',
        //    'password': '546er4AyaG1234912',
        //},
        'secure_ips': [
            '::ffff:46.238.228.238',
            '::ffff:51.255.85.92',
        ],
    },
    'sockets': [
        {'host': 'https://crimewheel.com', 'path': '/socket.io'},
    ],
};

///////////////////////////////////////////////////////////////////////////////////////////////////////

let redis = require("redis");
let io = require('socket.io-client');
let express = require('express');
let basicAuth = require('basic-auth-connect');
let bodyParser = require('body-parser');

let watt = require('watt');
let uuid = require('node-uuid');

let redis_db = (config['redis']['db'] === undefined)? 1: config['redis']['db'];
let redis_reader = redis.createClient(config['redis']);
let redis_writer = redis.createClient(config['redis']);

redis_reader.on("error", function (e) {
    console.error(e.toString());
    throw e;  //stop script
});

redis_writer.on("error", function (e) {
    console.error(e.toString());
    throw e;  //stop script
});


///////////////////////////////////////////////////////////////////////////////////////////////////////

function BotRequest(redis_reader, redis_writer) {
    this.reader = redis_reader;
    this.writer = redis_writer;

    this._response_timer = {};
    this._response_timer_cb = {};

    this._response_cbs = [];

    this.init_reader();
}

BotRequest.prototype.response_waiter = function(unique_id, timeout, cb) {
    let self = this;
    this._response_timer_cb[unique_id] = function(data) {
        if(data['is_exception']) {
            cb(data['return']);
        }
        else {
            cb(false, data['return']);
        }
    };
    this._response_timer[unique_id] = setTimeout(function() {
        delete self._response_timer[unique_id];
        delete self._response_timer_cb[unique_id];
        cb('Request timeout');
    }, timeout * 1000);
};

BotRequest.prototype.response_fill = function(unique_id, data) {
    //console.log('response_fill, ', unique_id, ' - ', data);

    if(unique_id in this._response_timer) {
        let timer_id = this._response_timer[unique_id];
        delete this._response_timer[unique_id];

        let cb = this._response_timer_cb[unique_id];
        delete this._response_timer_cb[unique_id];

        clearTimeout(timer_id);
        cb(data);
    }
};

BotRequest.prototype.init_reader = function() {
    let self = this;

    //odczytywanie request
    this.reader.subscribe(String(redis_db) + '#' + "any");
    this.reader.on("message", function (channel, message) {
        if(channel == (String(redis_db) + '#' + 'any')) {
            console.log('reader message: ', message);

            let data = JSON.parse(message);
            self._on_response(data['channel'], data['data']);
        }
    });
};

BotRequest.prototype._on_response = function(channel, data) {
    if(channel === 'request') {
        return;
    }

    if(channel === 'response') {
        this.response_fill(data['unique_id'], data);
    }
    this.response_emit(channel, data);
};

BotRequest.prototype.on_response = function(callback) {
    let unique_id = String(uuid.v1());
    this._response_cbs[unique_id] = callback;

    return unique_id;
};

BotRequest.prototype.unhook_response = function(unique_id) {
    delete this._response_cbs[unique_id];
};

BotRequest.prototype.response_emit = function(channel, data) {
    for(let key in this._response_cbs) {
        if(this._response_cbs.hasOwnProperty(key)) {
            this._response_cbs[key](channel, data);
        }
    }
};

BotRequest.prototype.request = function(method, unique_id, kwargs) {
    if(unique_id === null || unique_id === undefined) {
        unique_id = String(uuid.v1());
    }
    let data = {
        'unique_id': unique_id,
        'method': method,
        'kwargs': kwargs,
    };

    console.log('request: ', data);
    this.writer.publish(String(redis_db) + '#' + 'request', JSON.stringify(data));
};

BotRequest.prototype.sync_request = watt(function * (method, unique_id, kwargs, timeout, next) {
    if(unique_id === null || unique_id === undefined) {
        unique_id = String(uuid.v1());
    }
    this.request(method, unique_id, kwargs);
    return yield this.response_waiter(unique_id, timeout, next);
});

///////////////////////////////////////////////////////////////////////////////////////////////////////

function Web(bot, web_port, web_basic_auth, web_secure_ips) {
    this.bot = bot;
    this._app = express();

    this.web_port = (web_port == null)? 8000: web_port;
    this.web_basic_auth = (web_basic_auth == null)? null: web_basic_auth;
    this.web_secure_ips = (web_secure_ips == null)? null: web_secure_ips;
    this._init();
}

Web.prototype._init = function() {
    console.log('starting web');
    this._app.listen(this.web_port);

    this._app.use(bodyParser.json());
    this._app.use(bodyParser.urlencoded({ extended: true }));

    if(this.web_basic_auth != null) {
        this._app.use(basicAuth(this.web_basic_auth['username'], this.web_basic_auth['password']));
    }

    let self = this;
    let secure = function(req, res) {
        let ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        if(ip === '::ffff:127.0.0.1') {
            return true;
        }

        if(self.web_secure_ips != null) {
            for(let i=0; i<self.web_secure_ips.length; i++) {
               if(self.web_secure_ips[i] === ip || self.web_secure_ips[i] === '*') {
                   return true;
               }
            }
        }

        res.setHeader('Content-Type', 'text/plain');
        res.status(403);
        res.send('Not authorized');
        return false;
    };

    this._app.get('/api/v1/request/:method', function(req, res) {
        if(!secure(req, res)) { return; }
        self.on_api_request(req, res);
    });
    this._app.post('/api/v1/request/:method', function(req, res) {
        if(!secure(req, res)) { return; }
        self.on_api_request(req, res);
    });
    this._app.get('/api/v1/event/:method', function(req, res) {
        if(!secure(req, res)) { return; }
        self.on_event(req, res);
    });
};

Web.prototype.on_api_request = function(req, res) {
    console.log(req.body);
    let method = req.params['method'];
    let unique_id = req.body['unique_id'];
    delete req.body['unique_id'];

    let kwargs = req.body;

    this.bot.sync_request(method, unique_id, kwargs, 60, function(err, data) {
        if(err) {
            res.setHeader('Content-Type', 'text/plain');
            res.status(500);
            res.send(err);
        }
        else {
            res.setHeader('Content-Type', 'application/json');
            res.status(200);
            res.send(JSON.stringify(data));
        }
    });
};

Web.prototype.on_event = function(req, res) {
    let self = this;
    res.setHeader('Content-Type', 'application/json');
    let method = req.params['method'];

    res.status(206);
    res.write('connected\n');
    let unique_id = self.bot.on_response(function(channel, data) {
        if(method === 'all' || method === channel) {
            res.write(JSON.stringify({
                'channel': channel,
                'data': data,
            }) + '\n');
        }
    });

    req.on("close", function(err) {
        self.bot.unhook_response(unique_id);
    });
};


///////////////////////////////////////////////////////////////////////////////////////////

function Sockets(bot) {
    this.bot = bot;
    this._sockets = [];

    this._init();
}

Sockets.prototype._init = function() {
    let self = this;
    this.bot.on_response(function(channel, data) {
        if(channel !== 'response') {
            if(data['group'] == null) {
                self.emit('message', {
                    'channel': channel,
                    'data': data,
                    'group': null,
                });
            }
            else {
                self.emit('message', {
                    'channel': channel,
                    'data': data['data'],
                    'group': data['group'],
                });
            }
        }
    });
};

Sockets.prototype._init_socket = function(sock) {
    //gdy websocket chce wyslac request do bota
    let self = this;
    sock.on('request', function(data) {
        console.log('request incoming: ', JSON.stringify(data));
        self.bot.request(data['method'], data['unique_id'], data['kwargs']);
    });
};

Sockets.prototype.add_socket = function(url, path) {
    console.log('add websocket: ', url);
    let _settings = {
        reconnect: true,
        transports: ['websocket'],
        forceNew: true,
    };
    if(path != null) {
        _settings['path'] = path;
    }

    let _sock = io.connect(url, _settings);
    this._sockets.push(_sock);
    this._init_socket(_sock);
};

Sockets.prototype.emit = function(channel, data) {
    console.log('emit response: ', channel, JSON.stringify(data));

    for(let i = 0; i < this._sockets.length; i++) {
        if(this._sockets[i].connected) {
            this._sockets[i].emit(channel, data);
        }
    }
};


////////////////////////////////////////////////////////////////////////////////////////

let bot = new BotRequest(redis_reader, redis_writer);

if(config['web'] != null) {
    let web = new Web(bot, config['web']['port'], config['web']['basic_auth'], config['web']['secure_ips']);
}

if(config['sockets'] != null) {
    let socket = new Sockets(bot);
    for(let i=0; i<config['sockets'].length; i++) {
        let data = config['sockets'][i];
        socket.add_socket(data['host'], data['path']);
    }
}
