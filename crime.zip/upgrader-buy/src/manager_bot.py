import asyncio
import json
import time
import logging
import datetime
import traceback
import logging.config
import sys
import uuid
import random
import aioredis
import re
import motor.motor_asyncio

from typing import (
    Dict, Tuple, List, Awaitable, Union,
    Set, Any, Iterable, Iterator,
    Generator, AsyncIterator, AsyncIterable,
)
from json import JSONDecodeError

from bson import ObjectId
from pysteamweb import SteamWebBase, SteamIdParser
from pysteamweb.plugins import *

from async_timeout import timeout as async_timeout

from bitskins import *
from models import *
from utils import *
from manager_api import *

ADMINS_STEAM_ID = ('stid64',)


class BotConfig(object):
    STEAM_ID = 'stid64'
    USERNAME = 'login'
    PASSWORD = 'password'
    API_KEY = 'AB1E2E0189F9FBAB1CCFD8C234E03E2A'
    SHARED_2FA = 'a1yiTu3qP4scaX6kRSGIURBorA4='
    IDENTITY_2FA = '2WGKYo6l/MAqkq0azReqvPSXCYw='

LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'root': {
        'handlers': ['console'],
        'level': 'DEBUG'
    },
    'formatters': {
        'standard': {
            'format': '[%(asctime)s][%(levelname)s] %(name)s %(filename)s:%(funcName)s:%(lineno)d | %(message)s',
        },
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'formatter': 'standard',
        },
    },
}

logging.config.dictConfig(LOGGING)


class SteamMixin(SteamTrade, SteamMobileConfirmation, SteamWebBase):
    def __init__(self, *args, **kwargs):
        self._shared = kwargs.pop('shared', None)
        self._identity = kwargs.pop('identity', None)

        super().__init__(*args, **kwargs)

        self._mobile_data_by_mobile_id = dict()
        self._mobile_data_by_trade_id = dict()
        self._cache_cos = dict()

    @property
    def identity_secret(self):
        return self._identity

    @property
    def shared_secret(self):
        return self._shared

    def on_need_twofactor(self, kwargs, login_data):
        if not self.shared_secret:
            raise ValueError('You dont have two_factor in script!')
        else:
            kwargs['twofactorcode'] = self.generate_auth_code(self.shared_secret)
        return kwargs

    def get_price(self, market_hash_name):
        return None

    def _get_confirmation_query(self, tag, hash_time=None):
        if hash_time is None:
            hash_time = int(time.time())

        reusable = ['conf', 'details']
        if tag in reusable:
            if (time.time() - self._cache_cos.get(tag, (0, None))[0]) < 300:
                hash_time, k = self._cache_cos[tag]
            else:
                k = self.generate_hash_for_time(self.identity_secret, hash_time, tag)
                self._cache_cos[tag] = (hash_time, k)
        else:
            k = self.generate_hash_for_time(self.identity_secret, hash_time, tag)

        return {
            'p': self.device_id,
            'a': str(self.steam_id),
            'k': k,
            't': hash_time,
            'm': 'android',
            'tag': tag,
        }

    async def _update_mobile_confirmations(self):
        set_mobile = set()
        for data_confirm in (await self.get_confirmations(timeout=60)):
            mobile_id = data_confirm['id']
            set_mobile.add(mobile_id)
            if mobile_id in self._mobile_data_by_mobile_id:
                continue

            logging.info('get_confirmations: result={}'.format(data_confirm))
            self._mobile_data_by_mobile_id[mobile_id] = {
                'mobile': data_confirm,
                'trade_id': None,
                'start_time': time.time(),
            }

        self._mobile_data_by_mobile_id = dict(
            filter(lambda o: o[0] in set_mobile, self._mobile_data_by_mobile_id.items()))

        for mobile_id in list(self._mobile_data_by_mobile_id.keys()):
            if self._mobile_data_by_mobile_id.get(mobile_id, {}).get('trade_id'):
                continue

            ret = await self.get_confirmation_details(mobile_id, timeout=20)
            logging.info('get_confirmation_details: confirm_id={}, result={}'.format(mobile_id, ret))

            trade_id = None
            if ret.get('success', False):
                html_data = str(ret.get('html', ''))
                match = re.search(r'id="tradeofferid_(\d+)"', html_data)

                if match:
                    trade_id = int(match.group(1))
                else:
                    # trade_id not found
                    pass
            else:
                # failed get details
                pass

            # update variables
            if trade_id:
                data = self._mobile_data_by_mobile_id[mobile_id]
                data['trade_id'] = trade_id
                data['end_time'] = time.time()
                data['offset'] = data['end_time'] - data['start_time']

                self._mobile_data_by_mobile_id[mobile_id] = data
                self._mobile_data_by_trade_id[trade_id] = data

        # update data with liste
        self._mobile_data_by_trade_id = dict(map(
            lambda o: (o['trade_id'], o),
            filter(
                lambda o: o['trade_id'] is not None,
                self._mobile_data_by_mobile_id.values()
            )
        ))
        logging.debug('update _mobile_data_by_mobile_id: {}'.format(self._mobile_data_by_mobile_id))
        logging.debug('update _mobile_data_by_trade_id: {}'.format(self._mobile_data_by_trade_id))

    async def accept_mobile_by_trade_id(self, trade_id, timeout=60):
        trade_id = int(trade_id)

        async def try_get_mobile_data():
            while True:
                _mobile_data = self._mobile_data_by_trade_id.get(trade_id)
                if not _mobile_data:
                    await self._update_mobile_confirmations()
                    _mobile_data = self._mobile_data_by_trade_id.get(trade_id)

                if _mobile_data:
                    is_valid = await self.accept_confirmation(_mobile_data['mobile']['id'],
                                                              _mobile_data['mobile']['key'], timeout=20)
                    if is_valid.get('success', False):
                        return True

                # 5 to 30s
                await asyncio.sleep(random.randint(500, 3000) / 100)

        try:
            with async_timeout(timeout):
                return await try_get_mobile_data()
        except:
            pass
        return False


class RegisterBot(object):
    def __init__(self, connection):
        self._connection = connection

    async def register(self) -> dict:
        return await self.get_client()

    async def get_client(self) -> dict:
        return {
            "worker": "5b70e1de-cae8-11e6-8e4c-0242ac170004",
            "_id": BotConfig.STEAM_ID,

            "username": BotConfig.USERNAME,
            "password": BotConfig.PASSWORD,
            "api_key": BotConfig.API_KEY,
            "shared": BotConfig.SHARED_2FA,
            "identity": BotConfig.IDENTITY_2FA,
        }


class BotManager(object):
    def __init__(self, mongo_ip='localhost', mongo_port=27017, redis_ip='localhost', redis_port=6379, redis_db=1):
        self.bot_obj = None  # type: SteamMixin
        self.worker_id = None

        self._redis_ip = redis_ip
        self._redis_port = redis_port
        self._redis_db = redis_db

        self._mongo_ip = mongo_ip
        self._mongo_port = mongo_port
        self._connection = None
        self._redis_pub = None
        self._redis_sub = None

        self.model_trade = None  # type: TradeModel
        self.model_api = None  # type: APIModel

        self.game_manager = None  # type: GameManager

        self.event_queue = asyncio.Queue()

        self._current_eq = None
        self.locked_trades = set()

    async def set_redis(self, key: str, value: str, ttl: int = 0) -> None:
        await self._redis_pub.set(key, value, expire=ttl)
        return

    async def get_redis(self, key: str) -> Union[str, None]:
        return await self._redis_pub.get(key)

    async def del_redis(self, key: str) -> None:
        await self._redis_pub.delete(key)
        return

    async def one_check_trade(self, trade_id: int, document: dict, offer_data: Union[dict, None]) -> None:
        if self.bot_obj is None:
            raise ConnectionError('bot is not connected yet')

        logging.debug('start one_check_trade_tmp {}'.format(trade_id))

        if offer_data is None:
            data = await self.bot_obj.get_trade_offer(trade_id, timeout=5)
            offer_data = data.get('response', {}).get('offer', {})

        trade_type = document['type']
        if trade_type == self.model_trade.TYPE_SEND:
            await self.one_check_trade_send(trade_id, document, offer_data)
        elif trade_type == self.model_trade.TYPE_RECEIVED:
            await self.one_check_trade_received(trade_id, document, offer_data)
        return

    async def one_check_trade_received(self, trade_id: int, document: dict, offer_data: dict) -> None:
        request_uid = document['request_uid']
        trade_to_state = document['trade_to_state']
        trade_steam_id64 = document['trade_steam_id64']

        trade_offer_state = offer_data.get('trade_offer_state')
        if trade_offer_state == self.bot_obj.ETradeOfferState.Accepted:
            if document['is_check_their_assets']:
                await self.trade_accepted_pending(request_uid)
            else:
                await self.trade_accepted(request_uid, [])

        elif trade_offer_state in [
            self.bot_obj.ETradeOfferState.Canceled,
            self.bot_obj.ETradeOfferState.Declined,
            self.bot_obj.ETradeOfferState.InvalidItems,
            self.bot_obj.ETradeOfferState.Expired,
            self.bot_obj.ETradeOfferState.Countered,
            self.bot_obj.ETradeOfferState.CanceledBySecondFactor,
            self.bot_obj.ETradeOfferState.Invalid,
        ]:
            logging.debug('error, cancel - {} - {}'.format(trade_offer_state, trade_id))
            await self.trade_canceled(trade_id, request_uid, trade_offer_state)

        elif trade_offer_state in (self.bot_obj.ETradeOfferState.Active,):
            trade_request_retry = document['trade_request_retry']
            is_request_delay = document['is_request_delay']
            await self.model_trade.update_inc_trade_state_retry(request_uid)

            if not is_request_delay and trade_request_retry >= 12:
                await self.model_trade.update_trade_state_delay(request_uid)

            # wysylamy request co 5 razy anie co chwile...
            if is_request_delay:
                can_request_to_steam = trade_request_retry % 15 == 0
            else:
                can_request_to_steam = trade_request_retry % 5 == 0

            if can_request_to_steam:

                if trade_to_state == self.model_trade.STATE_TO_ACCEPT:
                    logging.debug('to_accept by active, {}'.format(trade_id))
                    r_data = await self.bot_obj.trade_accept(trade_id, trade_steam_id64)

                    if r_data.get('needs_mobile_confirmation'):
                        # if str(trade_steam_id64) in ADMINS_STEAM_ID:
                        logging.debug('CreatedNeedsConfirmation accept_mobile_by_trade_id {}'.format(trade_id))
                        await self.bot_obj.accept_mobile_by_trade_id(trade_id)
                        # else:
                        #     logging.debug('CreatedNeedsConfirmation trade_decline {}'.format(trade_id))
                        #     await self.bot_obj.trade_decline(trade_id)

                elif trade_to_state == self.model_trade.STATE_TO_CANCEL:
                    logging.debug('to_cancel by active, {}'.format(trade_id))
                    await self.bot_obj.trade_decline(trade_id)

                else:
                    logging.debug('to_cancel by none by active, {}'.format(trade_id))
                    await self.bot_obj.trade_decline(trade_id)

            else:
                logging.debug('to_state by active, {}, retry={}'.format(trade_id, trade_request_retry))

        elif trade_offer_state == self.bot_obj.ETradeOfferState.InEscrow:
            pass  # fixme pytanie co z tym status? jak sie zabezpieczyc?

        return

    async def one_check_trade_send(self, trade_id: int, document: dict, offer_data: dict) -> None:
        request_uid = document['request_uid']
        when_expire_at = document['when_expire_at']
        is_expired = when_expire_at < datetime.datetime.now()

        trade_offer_state = offer_data.get('trade_offer_state')
        if trade_offer_state == self.bot_obj.ETradeOfferState.Accepted:
            if document['is_check_their_assets']:
                await self.trade_accepted_pending(request_uid)
            else:
                await self.trade_accepted(request_uid, [])

        elif trade_offer_state in (self.bot_obj.ETradeOfferState.CreatedNeedsConfirmation,):
            # max 15s od stworzenia i wtedy usuwac to
            is_expired_2fa = (datetime.datetime.now() - document['send_at']).total_seconds() > 35
            if is_expired_2fa:
                logging.debug('is_expired_2fa, cancel - {}'.format(trade_id))
                await self.bot_obj.trade_cancel(trade_id)

        elif trade_offer_state in (
                self.bot_obj.ETradeOfferState.Canceled,
                self.bot_obj.ETradeOfferState.Declined,
                self.bot_obj.ETradeOfferState.InvalidItems,
                self.bot_obj.ETradeOfferState.Expired,
                self.bot_obj.ETradeOfferState.Countered,
                self.bot_obj.ETradeOfferState.CanceledBySecondFactor,
                self.bot_obj.ETradeOfferState.Invalid,
        ):
            if is_expired:
                logging.debug('is_expired by error, cancel - {}'.format(trade_id))
                await self.trade_expired(trade_id, request_uid)
            else:
                logging.debug('error, cancel - {} - {}'.format(trade_offer_state, trade_id))
                await self.trade_canceled(trade_id, request_uid, trade_offer_state)

        elif trade_offer_state in (
                self.bot_obj.ETradeOfferState.Active,
                self.bot_obj.ETradeOfferState.CreatedNeedsConfirmation,
        ):
            if is_expired:
                logging.debug('is_expired by active, cancel - {}'.format(trade_id))
                await self.bot_obj.trade_cancel(trade_id)

        elif trade_offer_state == self.bot_obj.ETradeOfferState.InEscrow:
            pass  # fixme pytanie co z tym status? jak sie zabezpieczyc?

        return

    def _parse_stickers_data(self, raw_sticker_string):
        match = re.search(r'Sticker: (.*?)</center>', raw_sticker_string)
        if not match:
            return []

        images = re.findall(r'src="([^"]+)">', raw_sticker_string)
        stickers_raw = match.group(1)
        stickers = list(map(lambda o: 'Sticker | {}'.format(o), stickers_raw.split(', ')))

        if len(stickers) != len(images):
            logging.critical('sticker len not match: {}'.format(raw_sticker_string))
            return []

        return list(map(lambda o: {
            'name': o[0],
            'img': o[1],
        }, zip(stickers, images)))

    @cache('backpack', 40, ['kwargs.get(\'steam_id\') or args[0]'])
    async def get_backpack(self, steam_id, timeout) -> dict:
        if self.bot_obj is None:
            raise ConnectionError('bot is not connected yet')

        try:
            response = await self.bot_obj.session.send_session(
                url='http://steamcommunity.com/inventory/{sid64}/{app_id}/{context_id}?l=english&count=5000'.format(
                    sid64=steam_id,
                    app_id=730,
                    context_id=2,
                ),
                is_post=False,
                is_json=True,
                timeout=timeout,
            )
        except JSONDecodeError:
            response = {
                'status': False,
                'Error': 'Steam is down',
            }
        except Exception:
            response = {
                'status': False,
                'Error': 'Steam is down or internal error',
            }

        if not response:
            response = {}

        logging.info('response eq: {}'.format(response))
        if not response.get('success', False):
            raise AssertionError(str(response.get('Error', 'Steam error')))

        if not response.get('assets', {}):
            return dict()

        dict_desc_by_key = self._map_desc_list_to_dict(response.get('descriptions', []))

        items = dict()
        for item in response.get('assets', []):
            try:
                data = self._one_item_to_universal(item, dict_desc_by_key)
            except AssertionError:
                continue

            items[data['asset_id']] = data

        return items

    def _grouping_backpack(self, datas, by_group, min_price=None):
        # by_group
        # 1 - po class_instance
        # 2 - po assetid
        # 2 - po market_hash_name
        items = dict()
        for data in datas:
            asset_id = data.pop('asset_id')
            if by_group == 1:
                key = '{}_{}'.format(data['class_id'], data['instance_id'])
            elif by_group == 2:
                key = int(asset_id)
            elif by_group == 3:
                key = data['market_hash_name']
            else:
                raise NotImplementedError()

            if min_price is not None:
                if data['price'] is None:
                    continue
                if data['price'] < min_price:
                    continue

            items.setdefault(key, data)
            items[key].setdefault('assets', list()).append(asset_id)
        return items

    async def get_my_backpack(self, get_mapped=None, get_sent=False, min_price=None, by_group=None):
        if self.bot_obj is None:
            raise ConnectionError('bot is not connected yet')

        # get_mapped = 1 # wszystko
        # 1 - wszystko
        # 2 - tylko zmapowane
        # 3 - tylko nie zmapowane

        # by_group
        # 1 - po class_instance
        # 2 - po assetid
        # 3 - po market_hash_name

        if get_mapped is None:
            get_mapped = 1

        if by_group is None:
            by_group = 1

        ret = await self.get_backpack(
            steam_id=self.bot_obj.steam_id.as_64(),
            timeout=60,
        )
        self._current_eq = len(ret)

        list_assets_in_eq = set(map(lambda o: int(o), ret.keys()))
        list_assets_only = list_assets_in_eq.copy()

        logging.debug('get_my_backpack, list_assets_in_eq: {}'.format(list_assets_in_eq))
        if get_sent is False:
            list_assets_in_trade = set()

            document_with_assets = await self.model_trade.get_status_sent_by_my_asset_id(list(list_assets_in_eq))
            for document in document_with_assets:
                set_assets = {
                    int(item['my_asset_id'])
                    for item in document['items_my_assets']
                    }
                list_assets_in_trade.update(list_assets_in_eq & set_assets)

            list_assets_can_trade = list_assets_in_eq - list_assets_in_trade
            list_assets_only = list_assets_only.intersection(list_assets_can_trade)
            logging.debug('get_my_backpack, list_assets_in_trade: {}'.format(list_assets_in_trade))
            logging.debug('get_my_backpack, list_assets_can_trade: {}'.format(list_assets_can_trade))

        if get_mapped == 1:
            # 1 - wszystko
            pass
        elif get_mapped == 2:
            # 2 - tylko zmapowane
            list_assets_mapped = set()

            document_with_assets = await self.model_trade.get_status_accepted_by_my_asset_id(list(list_assets_in_eq))
            for document in document_with_assets:
                set_assets = {
                    int(item['my_asset_id'])
                    for item in document['items_their_assets']
                    }
                list_assets_mapped.update(list_assets_in_eq & set_assets)

            list_assets_only = list_assets_only.intersection(list_assets_mapped)
            logging.debug('get_my_backpack, list_assets_mapped: {}'.format(list_assets_mapped))

        elif get_mapped == 3:
            # 3 - tylko nie zmapowane
            list_assets_mapped = set()

            document_with_assets = await self.model_trade.get_status_accepted_by_my_asset_id(list(list_assets_in_eq))
            for document in document_with_assets:
                set_assets = {
                    int(item['my_asset_id'])
                    for item in document['items_their_assets']
                    }
                list_assets_mapped.update(list_assets_in_eq & set_assets)

            list_assets_not_mapped = list_assets_in_eq - list_assets_mapped
            list_assets_only = list_assets_only.intersection(list_assets_not_mapped)
            logging.debug('get_my_backpack, list_assets_mapped: {}'.format(list_assets_mapped))
            logging.debug('get_my_backpack, list_assets_not_mapped: {}'.format(list_assets_not_mapped))

        ret_filtered = list(filter(lambda o: int(o['asset_id']) in list_assets_only, ret.values()))
        logging.debug('get_my_backpack, list_assets_only: {}'.format(list_assets_only))
        logging.debug('get_my_backpack, ret_filtered: {}'.format(ret_filtered))
        return self._grouping_backpack(ret_filtered, by_group, min_price=min_price)

    async def get_their_backpack(self, steam_id, min_price=None, by_group=None):
        if by_group is None:
            by_group = 1

        ret = await self.get_backpack(
            steam_id=SteamIdParser(steam_id).as_64(),
            timeout=60,
        )
        ret_filtered = ret.values()
        return self._grouping_backpack(ret_filtered, by_group, min_price=min_price)

    ######## PUBLICZNE EVENTY #########
    async def trade_accepted(self, request_uid, items_their_assets):
        await self.model_trade.update_accepted(request_uid, items_their_assets)
        await self.create_and_send_event_by_trade(request_uid)

    async def trade_accepted_pending(self, request_uid):
        await self.model_trade.update_accepted_pending(request_uid)
        await self.create_and_send_event_by_trade(request_uid)

    async def trade_canceled(self, trade_id, request_uid, trade_offer_state):
        await self.model_trade.update_error(request_uid, 'Cancel - {}'.format(trade_offer_state))
        await self.create_and_send_event_by_trade(request_uid)

    async def trade_error(self, request_uid, error):
        await self.model_trade.update_error(request_uid, error)
        await self.create_and_send_event_by_trade(request_uid)

    async def trade_expired(self, trade_id, request_uid):
        await self.model_trade.update_expired(request_uid)
        await self.create_and_send_event_by_trade(request_uid)

    async def trade_sent(self, request_uid, trade_id, ttl_expire_send, items_my_assets, items_their_assets):
        await self.model_trade.update_sent(request_uid, trade_id, ttl_expire_send, items_my_assets, items_their_assets)
        await self.create_and_send_event_by_trade(request_uid)

    ################END###############

    async def check_sent_and_received(self):
        if self.bot_obj is None:
            raise ConnectionError('bot is not connected yet')

        # todo trzeba dodac sprawdzanie, czy czasem dany trade_id nie jest juz zaakceptowany lub anulowany, bo steam roznie zwraca (w momencie gdy pada)
        # pobiera aktywne trade
        offers = (await self.bot_obj.get_trade_offers(
            get_sent_offers=True,
            get_received_offers=True,
            timedelta_cutoff=0,
            timeout=10,
        )).get('response', {})
        dict_desc_by_key = self._map_desc_list_to_dict(offers.get('descriptions', []))

        # pobiera trade ktory sa wyslane, zeby sprawdzic ich status
        dict_by_trades = {}
        for document in (await self.model_trade.get_status_check()):
            trade_id = int(document['trade_id'])
            if self.is_lock_trade_id(trade_id):
                continue

            dict_by_trades[trade_id] = document

        dict_api_by_trades = {}
        list_trade_not_in_db = []
        for trade in offers.get('trade_offers_sent', []):
            trade_id = int(trade['tradeofferid'])
            dict_api_by_trades[trade_id] = trade

            if self.is_lock_trade_id(trade_id):
                continue

            # gdy nie ma tego trade w bazie to usuwamy z aktywnych!
            if trade_id not in dict_by_trades:
                if trade.get('trade_offer_state') in [
                    self.bot_obj.ETradeOfferState.Active,
                    self.bot_obj.ETradeOfferState.CreatedNeedsConfirmation
                ]:
                    list_trade_not_in_db.append(trade_id)

        list_trade_to_manager = []
        for trade in offers.get('trade_offers_received', []):
            trade_id = int(trade['tradeofferid'])
            dict_api_by_trades[trade_id] = trade

            if self.is_lock_trade_id(trade_id):
                continue

            # manager gry zajmuje sie anulowaniem przychodzacych trade
            # do managera maja trafiac tylko te trade ktorych nie ma w bazie
            if trade_id not in dict_by_trades:
                if trade.get('trade_offer_state') == self.bot_obj.ETradeOfferState.Active:
                    list_trade_to_manager.append((trade_id, trade))

        # automatyczne anulowanie trejdow ktorych nie ma w DB!
        for trade_id in list_trade_not_in_db:
            # wrzucenie w tÅ‚o bo nie interesuje nas status
            logging.debug('dict_trade_not_in_db, cancel - {}'.format(trade_id))
            asyncio.ensure_future(self.bot_obj.trade_cancel(trade_id))

        # emit to game manager
        for trade_id, trade_data in list_trade_to_manager:
            await self.game_manager.on_manager_receive_trade(trade_id, self._map_trade_data_to_universal(trade_data,
                                                                                                         dict_desc_by_key))

        # sprawdza
        list_of_tasks = list()
        for trade_id, document in dict_by_trades.items():
            offer_data = dict_api_by_trades.get(trade_id, None)

            # fixme czy to nie bedzie spowalniac!
            tsk = asyncio.ensure_future(self.one_check_trade(trade_id, document, offer_data))
            list_of_tasks.append(tsk)

        if list_of_tasks:
            await asyncio.gather(*list_of_tasks)

    @forever_reset_on_raise(sleep=4)  # fixme czas
    async def worker_check_sent_and_received(self):
        await self.check_sent_and_received()

    def _map_desc_list_to_dict(self, list_desc) -> dict:
        return {
            '{}_{}'.format(
                doc.get('classid', 0),
                doc.get('instanceid', 0),
            ): doc
            for doc in list_desc
            }

    def _one_item_to_universal(self, item, desc_by_key) -> dict:
        key = '{}_{}'.format(
            item.get('classid', 0),
            item.get('instanceid', 0),
        )
        desc = desc_by_key.get(key, {})
        item_asset_id = int(item.get('assetid', 0))

        if not desc.get('tradable'):
            raise AssertionError('this item is not tradable!')  # FIXME ?
            # return None

        exterior = [
            d['value'].replace('Exterior:', '').strip()
            for d in desc.get('descriptions', [])
            if d.get('value', '').startswith('Exterior:')
            ]

        list_sticker_raw = [
            d.get('value', '')
            for d in desc.get('descriptions', [])
            if 'title="Sticker Details"' in d.get('value', '')
            ]

        list_inspect = [
            d.get('link')
            for d in desc.get('actions', [])
            if d.get('name', '') == 'Inspect in Game...' and d.get('link')
            ]
        inspect = list_inspect[0] if list_inspect else None
        if inspect:
            inspect = inspect.replace('%owner_steamid%', str(self.bot_obj.steam_id.as_64()))
            inspect = inspect.replace('%assetid%', str(item_asset_id))

        price = self.bot_obj.get_price(desc['market_hash_name'])
        return {
            'unique_id': str(uuid.uuid4()),
            'app_id': int(item['appid']),

            'class_id': item.get('classid', 0),
            'instance_id': item.get('instanceid', 0),
            'icon_url': desc.get('icon_url'),
            'icon_url_large': desc.get('icon_url_large'),
            'name_color': desc.get('name_color'),
            'market_hash_name': desc['market_hash_name'],
            'name': desc['name'],
            'exterior': exterior[0] if exterior else None,
            'inspect': inspect,
            'price': price,
            'stickers': self._parse_stickers_data(list_sticker_raw[0]) if list_sticker_raw else [],
            'asset_id': item_asset_id,
        }

    def _map_trade_data_to_universal(self, trade_data: dict, desc_by_key: dict) -> dict:
        items_my_assets = []
        items_their_assets = []

        for item in trade_data.get('items_to_give', []):
            data = self._one_item_to_universal(item, desc_by_key)
            asset_id = data.pop('asset_id')

            data['my_asset_id'] = asset_id
            data['their_asset_id'] = None
            items_my_assets.append(data)

        for item in trade_data.get('items_to_receive', []):
            data = self._one_item_to_universal(item, desc_by_key)
            asset_id = data.pop('asset_id')

            data['my_asset_id'] = None
            data['their_asset_id'] = asset_id
            items_their_assets.append(data)

        return {
            'trade_id': int(trade_data['tradeofferid']),
            'steam_id64': SteamIdParser(trade_data['accountid_other']).as_64(),
            'message': trade_data.get('message', ''),

            'items_my_assets': items_my_assets,
            'items_their_assets': items_their_assets,
        }

    def set_lock_trade_id(self, trade_id):
        self.locked_trades.add(int(trade_id))

    def set_unlock_trade_id(self, trade_id):
        try:
            self.locked_trades.remove(int(trade_id))
        except KeyError:
            pass

    def is_lock_trade_id(self, trade_id) -> bool:
        return int(trade_id) in self.locked_trades

    async def one_send_trade(self, document):
        if self.bot_obj is None:
            raise ConnectionError('bot is not connected yet')

        request_uid = document['request_uid']
        trade_url = 'https://steamcommunity.com/tradeoffer/new/?partner={partner}&token={token}'.format(
            partner=SteamIdParser(document['trade_steam_id64']).as_account(),
            token=document['trade_token'],
        )

        data_can_trade = await self.bot_obj.check_user_trade_url(trade_url)
        if not data_can_trade['is_valid']:
            await self.trade_error(request_uid, 'Trade url: {}'.format(
                data_can_trade['message'],
            ))
            return

        items_my = []
        items_my_assets = []
        items_their = []
        items_their_assets = []

        _items_my = document['items']['my']
        _items_their = document['items']['their']
        if _items_my:
            _items_my_eq = await self.get_my_backpack(get_sent=False, by_group=2)
            _items_not_eq = set()
            for key_asset_id in _items_my:
                key_asset_id = int(key_asset_id)
                _item_eq = _items_my_eq.pop(key_asset_id, None)
                if not _item_eq:
                    _items_not_eq.add(str(key_asset_id))
                    continue

                asset_id = int(_item_eq.pop('assets', [])[0])
                items_my.append({
                    'appid': 730,
                    'contextid': '2',
                    'amount': 1,
                    'assetid': str(asset_id),
                })

                item_data = _item_eq.copy()
                item_data['my_asset_id'] = asset_id
                item_data['their_asset_id'] = None
                items_my_assets.append(item_data)

            if _items_not_eq:
                await self.trade_error(request_uid, 'Not item in my EQ: {}'.format(
                    ','.join(_items_not_eq),
                ))
                return

        if _items_their:
            _items_their_eq = await self.get_their_backpack(document['trade_steam_id64'], by_group=2)
            _items_not_eq = set()
            for key_asset_id in _items_their:
                key_asset_id = int(key_asset_id)
                _item_eq = _items_their_eq.get(key_asset_id)
                if not _item_eq:
                    _items_not_eq.add(str(key_asset_id))
                    continue

                asset_id = int(_item_eq.pop('assets', [])[0])
                items_their.append({
                    'appid': 730,
                    'contextid': '2',
                    'amount': 1,
                    'assetid': str(asset_id),
                })

                item_data = _item_eq.copy()
                item_data['my_asset_id'] = None
                item_data['their_asset_id'] = asset_id
                items_their_assets.append(item_data)

            if _items_not_eq:
                await self.trade_error(request_uid, 'Not item in their EQ: {}'.format(
                    ','.join(_items_not_eq),
                ))
                return

        try:
            trade_data = await self.bot_obj.trade_send(
                trade_hash_url=trade_url,
                items=[
                    items_my,
                    items_their,
                ],
                msg=document['trade_message'],
            )
        except Exception as e:
            logging.critical('trade_send failed, {}, {}'.format(
                e,
                traceback.format_exc(),
            ))
            trade_data = {'strError': str(e)}

        trade_offer_id = trade_data.get('tradeofferid')
        if trade_offer_id is None:
            # todo pytanie jak sprawdziÄ‡ czy napewno wysÅ‚aÅ‚o? - to juz user powinien sam widziec ze mu nie zaakceptowal i ze jest inny token trade!
            await self.trade_error(request_uid, 'Send error: {}'.format(
                str(trade_data.get('strError')),
            ))
            return
        self.set_lock_trade_id(trade_offer_id)

        if items_my:
            try:
                is_confirmation_ok = await self.bot_obj.accept_mobile_by_trade_id(trade_offer_id)
            except Exception as e:
                logging.critical('accept_mobile_by_trade_id failed, {}, {}'.format(
                    e,
                    traceback.format_exc(),
                ))
                is_confirmation_ok = False
        else:
            is_confirmation_ok = True

        if is_confirmation_ok:
            await self.trade_sent(request_uid, trade_offer_id, document.get('ttl_expire_send', 60), items_my_assets,
                                  items_their_assets)
            self.set_unlock_trade_id(trade_offer_id)
        else:
            asyncio.ensure_future(self.bot_obj.trade_cancel(trade_offer_id))
            await self.trade_error(request_uid, 'Confirmation failed')
            self.set_unlock_trade_id(trade_offer_id)

    @forever_reset_on_raise(sleep=2)  # fixme czas
    async def worker_to_send(self):
        # todo teoretycznie mozna to wpiÄ…Ä‡ jako asyncio waiter, przykÅ‚ad tutaj: https://github.com/patryk4815/GameQuery/blob/alpha-async/query/connection/udp.py
        # todo dodac sprawdzanie ile aktualnie jest w wyslanych (juz w kolejce)
        trades_to_send = await self.model_trade.get_status_to_send()
        if not trades_to_send:
            return

        for document in trades_to_send:
            when_expire_at = document['when_expire_at']
            is_expired = when_expire_at < datetime.datetime.now()
            if is_expired:
                await self.trade_expired(None, document['request_uid'])
                continue

            await self.one_send_trade(document)
            await asyncio.sleep(3)

    def send_api_event(self, document):
        self.event(document['response_channel'], {
            'event_id': str(document['_id']),
            'event_created_at': document['created_at'].timestamp(),
            'request_uid': str(document['request_uid']),
            'timestamp': time.time(),
            'data': document['response_data'],
        })

    async def create_and_send_event_by_trade(self, request_uid):
        trade_document = await self.model_trade.get_by_request_uid(request_uid)
        api_result = await self.model_api.init(
            request_uid=request_uid,
            response_channel='trade_data',
            response_data={
                'type': trade_document.get('type'),
                'trade_to_state': trade_document.get('trade_to_state'),
                'trade_steam_id64': trade_document.get('trade_steam_id64'),

                'trade_id': trade_document.get('trade_id'),
                'trade_message': trade_document.get('trade_message'),
                'items': trade_document.get('items'),

                'is_check_their_assets': trade_document.get('is_check_their_assets'),
                'items_their_in_my_eq': {str(data['their_asset_id']): data['my_asset_id'] for data in
                                         trade_document.get('items_their_assets', [])},

                'items_their_assets': trade_document.get('items_their_assets'),
                'items_my_assets': trade_document.get('items_my_assets'),

                'status': trade_document.get('status'),
                'send_error': trade_document.get('send_error'),

                'created_at': trade_document.get('created_at'),
                'expire_at': trade_document.get('expire_at'),
                'send_at': trade_document.get('send_at'),
                'accepted_at': trade_document.get('accepted_at'),
                'accepted_pending_at': trade_document.get('accepted_pending_at'),
                'error_at': trade_document.get('error_at'),
            },
        )
        api_document = await self.model_api.get_by_id(api_result.inserted_id)
        self.send_api_event(api_document)

    @forever_reset_on_raise(sleep=5)  # fixme czas
    async def worker_api_worker(self):
        for document in (await self.model_api.get_status_sent()):
            _id = document['_id']

            is_expired = document['when_expire_at'] < datetime.datetime.now()
            if is_expired:
                await self.model_api.update_expired(_id)
                continue

            is_too_fast = (time.time() - document['last_update']) < 30
            if is_too_fast:
                continue

            await self.model_api.update_time(_id)
            self.send_api_event(document)

    @forever_reset_on_raise(sleep=2)
    async def worker_check_eq(self):
        # todo teoretycznie mozna to wpiÄ…Ä‡ jako asyncio waiter, przykÅ‚ad tutaj: https://github.com/patryk4815/GameQuery/blob/alpha-async/query/connection/udp.py
        # todo dodac sprawdzanie ile aktualnie jest w wyslanych (juz w kolejce)
        trades_to_check = await self.model_trade.get_status_accepting_pending()
        if not trades_to_check:
            return

        logging.debug('start worker_check_eq')
        eq_data = await self.get_my_backpack(get_sent=False, get_mapped=3, by_group=3)
        logging.debug('worker_check_eq, eq_data: {}'.format(eq_data))

        eq_used = set()
        for document in trades_to_check:
            items_their_assets = document['items_their_assets'].copy()

            is_valid_all = True
            _eq_tmp = set()
            for item in items_their_assets:
                key = item['market_hash_name']
                item_eq = eq_data.get(key)
                if not item_eq:
                    is_valid_all = False
                    break

                _eq_used_assets = eq_used | _eq_tmp
                _free_assets = list(filter(lambda _aid: int(_aid) not in _eq_used_assets, item_eq['assets']))
                asset_id = _free_assets[0] if _free_assets else None
                if asset_id is None:
                    is_valid_all = False
                    break

                asset_id = int(asset_id)
                _eq_tmp.add(asset_id)
                item['my_asset_id'] = asset_id

            if not is_valid_all:
                continue

            eq_used.update(_eq_tmp)
            await self.trade_accepted(
                document['request_uid'],
                items_their_assets,
            )

        logging.debug('end worker_check_eq')
        await asyncio.sleep(10)

    def send_websocket_channel(self, channel, data, timeout=None):
        asyncio.ensure_future(self._send_websocket_channel(channel, data, timeout=timeout))

    async def _send_websocket_channel(self, channel, data, timeout=None):
        if timeout is not None:
            await asyncio.sleep(timeout)

        await self._redis_pub.publish('{}#any'.format(self._redis_db), json.dumps({
            'channel': channel,
            'data': data,
        }, cls=LazyJSONEncoder))

    def response(self, unique_id, is_exception, return_):
        self.send_websocket_channel('response', {
            'unique_id': unique_id,
            'is_exception': is_exception,
            'return': return_,
        })

    def event(self, channel, data):
        # self.send_websocket_channel('event', {
        #     'channel': channel,
        #     'data': data,
        # })
        self.event_queue.put_nowait((channel, data))

    async def close(self):
        if not self._connection:
            return False

        self._redis_pub.close()
        await asyncio.sleep(0)
        await self._redis_pub.wait_closed()
        await self._redis_sub.wait_closed()

        self._redis_pub = None
        self._redis_sub = None
        self._connection = None
        return True

    # API RESPONSE
    async def task_w4_send_trade(self, *, request_uid, trade_partner, trade_token, items, trade_message,
                                 expire) -> dict:
        await self.model_trade.init_send(
            trade_partner=trade_partner,
            trade_token=trade_token,
            items=items,
            trade_message=trade_message,
            request_uid=request_uid,
            expire=expire,
        )

        return {
            'type': 1,  # background
            'data': None,
        }

    async def task_w4_send_trade_by_id(self, *, request_uid, trade_id, trade_partner, trade_token, trade_message,
                                       expire) -> dict:
        document = await self.model_trade.get_by_trade_id(int(trade_id))
        if not document:
            raise AssertionError('not found trade_id: {}'.format(trade_id))

        items = {
            'my': [],
            'their': [],
        }
        if trade_partner is None:
            trade_partner = document['trade_steam_id64']
        if trade_token is None:
            trade_token = document['trade_token']

        for item in document['items_their_assets']:
            if not item['my_asset_id']:
                raise AssertionError('trade found but, not all items: {}'.format(item))

            items['my'].append(str(item['my_asset_id']))

        return await self.task_w4_send_trade(
            request_uid=request_uid,
            trade_partner=trade_partner,
            trade_token=trade_token,
            items=items,
            trade_message=trade_message,
            expire=expire,
        )

    async def task_w4_check_asset_id(self, *, asset_id) -> list:
        asset_id = int(asset_id)
        list_data = list()
        async for document in self.model_trade.collection.find({
            '$or': [
                {'items_my_assets.my_asset_id': asset_id},
                {'items_their_assets.my_asset_id': asset_id},
            ]
        }):
            list_data.append(document)
        return list_data

    async def task_w4_check_trade_id(self, *, trade_id, is_steam_api) -> dict:
        if self.bot_obj is None:
            raise ConnectionError('bot is not connected yet')

        trade_id = int(trade_id)
        is_steam_api = bool(int(is_steam_api))
        if is_steam_api:
            data = await self.bot_obj.get_trade_offer(trade_id, timeout=5)
            offer_data = data.get('response', {}).get('offer', {})
            return offer_data

        document = await self.model_trade.get_by_trade_id(trade_id)
        if not document:
            return {}

        return document

    async def task_w4_check_request_id(self, *, request_uid) -> Union[dict, None]:
        return await self.model_trade.get_by_request_uid(request_uid)

    async def task_w4_get_my_backpack(self, *, get_sent=False, min_price=None, by_group=1) -> dict:
        ret = await self.get_my_backpack(get_sent=get_sent, min_price=min_price, by_group=by_group)
        return {
            'type': 0,
            'data': ret,
        }

    async def task_w4_get_their_backpack(self, *, steam_id: str, min_price: str=None, by_group: int=1) -> dict:
        if min_price is not None:
            min_price = Decimal(min_price)

        ret = await self.get_their_backpack(steam_id=steam_id, min_price=min_price, by_group=by_group)
        return {
            'type': 0,
            'data': ret,
        }

    async def task_w4_set_accepted(self, *, event_id) -> dict:
        await self.model_api.update_closed(ObjectId(event_id))
        return {
            'type': 0,
            'data': {
                'status': 'OK'
            },
        }

    async def task_w4_get_current_trade_queue(self) -> list:
        documents = list()
        documents.extend(await self.model_trade.get_status_sent())
        documents.extend(await self.model_trade.get_status_to_send())
        return documents

    @forever_reset_on_raise(sleep=30)  # tylko zabezpieczenie gdy padnie
    async def worker_subscriber(self):
        logging.info('start worker_subscriber')
        ch_request, = await self._redis_sub.subscribe('{}#request'.format(self._redis_db))

        logging.info('start ch_request')
        async for dict_data in ch_request.iter(encoding='utf-8', decoder=json.loads):
            logging.info('loop ch_request: {}'.format(dict_data))

            unique_id = dict_data.get('unique_id', None)
            if not unique_id:
                continue

            method_name = 'task_w4_' + dict_data.get('method', '')
            kwargs = dict_data.get('kwargs')
            method = getattr(self, method_name, None)

            if not method:
                # odpowiedz
                self.response(
                    unique_id=unique_id,
                    is_exception=True,
                    return_='Method not found or not args',
                )
                continue

            if not kwargs:
                kwargs = {}

            try:
                ret = await method(**kwargs)

                self.response(
                    unique_id=unique_id,
                    is_exception=False,
                    return_=ret,
                )
            except Exception as e:
                logging.critical('api response error: {}'.format(traceback.format_exc()))
                # odpowiedz gdy blad
                self.response(
                    unique_id=unique_id,
                    is_exception=True,
                    return_=str(e),
                )

        logging.info('end ch_request')
    #####################################

    async def connect(self):
        if self._connection:
            return False

        connection = motor.motor_asyncio.AsyncIOMotorClient(self._mongo_ip, self._mongo_port)
        self._connection = connection

        redis = await aioredis.create_redis((self._redis_ip, self._redis_port), db=self._redis_db)
        self._redis_pub = redis

        sub = await aioredis.create_redis((self._redis_ip, self._redis_port), db=self._redis_db)
        self._redis_sub = sub

        register = RegisterBot(self._connection)
        bot_data = await register.register()

        steam_id = bot_data['_id']
        self.worker_id = bot_data['worker']
        self.bot_obj = SteamMixin(
            shared=bot_data['shared'],
            identity=bot_data['identity'],
            api_key=bot_data['api_key'],
            username=bot_data['username'],
            password=bot_data['password'],
        )
        await self.bot_obj.__aenter__()
        self.bot_obj.session.set_cookies({
            'Steam_Language': 'english',
        })

        self.model_trade = TradeModel(self._connection, steam_id)
        self.model_api = APIModel(self._connection, steam_id)

        self.game_manager = GameManager(bot_manager=self)
        await self.game_manager.connect()

        asyncio.ensure_future(self.worker_check_sent_and_received())
        asyncio.ensure_future(self.worker_to_send())
        asyncio.ensure_future(self.worker_subscriber())
        asyncio.ensure_future(self.worker_api_worker())
        asyncio.ensure_future(self.worker_check_eq())

        return True

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def forever(self):
        while True:
            logging.debug('init')
            await asyncio.sleep(30)


#######################################################################################################################


async def main():
    async with BotManager(
        mongo_ip='mongo',
        mongo_port=27017,
        redis_ip='redis',
        redis_port=6379,
        redis_db=1,
    ) as s:
        await s.forever()


if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
    loop.close()