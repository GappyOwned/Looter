import datetime
import logging
import json
import asyncio
import traceback

from bson import ObjectId, Decimal128
from decimal import Decimal as DecimalBase


class DecimalPatch(Decimal128):
    def __init__(self, value):
        if isinstance(value, Decimal128):
            value = str(value)
        super().__init__(value)

    def __sub__(self, other):
        return DecimalPatch(DecimalBase(str(self)) - DecimalBase(str(other)))

    def __add__(self, other):
        return DecimalPatch(DecimalBase(str(self)) + DecimalBase(str(other)))

    def __truediv__(self, other):
        return DecimalPatch(DecimalBase(str(self)) / DecimalBase(str(other)))

    def __mul__(self, other):
        return DecimalPatch(DecimalBase(str(self)) * DecimalBase(str(other)))

    def __int__(self):
        return int(self.to_decimal())

    def __radd__(self, other):
        if other == 0:
            return self
        else:
            return self.__add__(other)

    def __lt__(self, other):
        return DecimalBase(str(self)) < DecimalBase(str(other))

    def __gt__(self, other):
        return DecimalBase(str(self)) > DecimalBase(str(other))

    def __le__(self, other):
        return DecimalBase(str(self)) <= DecimalBase(str(other))

    def __ge__(self, other):
        return DecimalBase(str(self)) >= DecimalBase(str(other))

Decimal = DecimalPatch

__all__ = (
    'forever_reset_on_raise',
    'JsonPythonEncoder',
    'json_python_decoder',
    'LazyJSONEncoder',
    'ExDeclineTrade',
    'cache',
    'Decimal',
)


def forever_reset_on_raise(sleep, append_is_first=False):
    def wrap(func):
        async def _inner(self, *args, **kwargs):
            is_first = True
            while True:
                try:
                    if append_is_first:
                        kwargs['is_first'] = is_first
                    await func(self, *args, **kwargs)
                except:
                    logging.critical(traceback.format_exc())
                await asyncio.sleep(sleep)
                is_first = False

        return _inner

    return wrap


class JsonPythonEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return {
                '__decimal__': True,
                'value': str(obj),
            }

        return super().default(obj)


def json_python_decoder(data):
    if '__decimal__' in data:
        return Decimal(data['value'])
    return data


class LazyJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        try:
            iterable = iter(obj)
        except TypeError:
            pass
        else:
            return list(iterable)

        if isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, datetime.date):
            return obj.strftime('%Y-%m-%d')
        elif isinstance(obj, Decimal128):
            return str(obj)
        elif isinstance(obj, Decimal):
            return str(obj)
        elif isinstance(obj, ObjectId):
            return str(obj)

        return super().default(obj)


class ExDeclineTrade(Exception):
    pass


def cache(name, ttl, parameters):
    def _wrap(func):
        async def _inner(self, *args, **kwargs):
            cache_key = name

            if parameters:
                for arg_eval in parameters:
                    try:
                        val = eval(arg_eval)
                        cache_key += '_' + str(val)
                    except (KeyError, IndexError) as e:
                        pass

            ret = await self.get_redis(cache_key)
            if ret is not None:
                ret2 = json.loads(ret.decode(), object_hook=json_python_decoder)
                if isinstance(ret2, dict) and ret2.get('is_exception', False):
                    raise Exception(ret2['data'])
                return ret2

            try:
                ret = await func(self, *args, **kwargs)
                await self.set_redis(cache_key, json.dumps(ret, cls=JsonPythonEncoder), ttl)
            except Exception as e:  # todo OWN EXCEPTION!
                ret = {'is_exception': True, 'data': str(e)}
                await self.set_redis(cache_key, json.dumps(ret, cls=JsonPythonEncoder), ttl)
                raise Exception(str(e))

            return ret

        return _inner

    return _wrap
