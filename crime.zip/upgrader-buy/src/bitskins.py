from pprint import pprint
from typing import Union, List, Dict, Tuple

import aiohttp
import logging

import asyncio

import math
import onetimepass
from decimal import Decimal

logging.basicConfig(level=logging.DEBUG)


class Bitskins(object):
    def get_bitskins_token(self):
        return onetimepass.get_totp('Y73QRDKQPE6Z2FYD')

    def get_bitskins_apikey(self):
        return 'a2ea9eb5-c2cc-4dee-aeb8-4e8b51d8eefa'

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        pass

    async def request(self, url, params=None, data=None, is_post=False, is_json=True, timeout=60):
        async with aiohttp.ClientSession() as session:
            if is_post:
                method = getattr(session, 'post')
                kwargs = {
                    'url': url,
                    'params': params,
                    'data': data,
                    'timeout': timeout,
                }
            else:
                method = getattr(session, 'get')
                kwargs = {
                    'url': url,
                    'params': params,
                    'timeout': timeout,
                }

            async with method(**kwargs) as resp:
                if is_json:
                    try:
                        return await resp.json()
                    except:
                        logging.critical('error prasing response: {}'.format(
                            await resp.text(),
                        ))
                        raise
                return await resp.text()

    async def get_bitskins_api(self, method, params=None) -> Union[None, dict]:
        if params is None:
            params = {}

        params['api_key'] = self.get_bitskins_apikey()
        params['code'] = self.get_bitskins_token()
        data = await self.request(
            url='https://bitskins.com/api/v1/{method}/'.format(
                method=method,
            ),
            params=params,
            is_post=False,
            is_json=True,
            timeout=60,
        )
        if data.get('status') != 'success':
            logging.critical('error on bitskins api: {}'.format(data))
            return None

        return data

    async def get_balance(self) -> dict:
        data = await self.get_bitskins_api('get_account_balance')
        return data['data']

    async def get_balance_available(self) -> Decimal:
        data = await self.get_balance()
        return Decimal(data['available_balance'])

    async def get_prices(self) -> Dict[str, Decimal]:
        data = await self.get_bitskins_api('get_all_item_prices')
        return {
            d['market_hash_name']: d['price']
            for d in data['prices']
        }

    async def get_items_by_name(self, list_weapons):
        data = await self.get_bitskins_api('get_price_data_for_items_on_sale', params={
            'names': ','.join(list_weapons)
        })
        # upto 250 market_hash_names from BitSkins at a time
        # total_items
        return data['data']['items']

    async def get_withdraw_item(self, items_ids: list):
        data = await self.get_bitskins_api('withdraw_item', params={
            'item_ids': ','.join(map(str, items_ids)),
        })
        return data

    async def get_buy_item(self, items_with_price: dict):
        data = await self.get_bitskins_api('buy_item', params={
            'item_ids': ','.join(map(str, items_with_price.keys())),
            'prices': ','.join(map(str, items_with_price.values())),
        })
        return data

    async def get_sell_item(self, items_ids: list):
        data = await self.get_bitskins_api('list_item_for_sale', params={
            'item_ids': ','.join(map(str, items_ids)),
            'prices': ','.join(map(str, items_ids)),
        })
        return data

    async def get_trade_details(self, trade_id, trade_token):
        data = await self.get_bitskins_api('get_trade_details', params={
            'trade_token': trade_token,
            'trade_id': trade_id,
        })
        return data

    async def get_sell_items_by_name(self, weapon_name: str) -> list:
        data = await self.get_bitskins_api('get_inventory_on_sale', params={
            'sort_by': 'price',  # {created_at|price|wear_value}
            'order': 'asc',
            'page': 1,
            'per_page': 480,
            'is_souvenir': '0',
            'market_hash_name': weapon_name,
        })
        return list(
            filter(
                lambda d: not d['is_mine'],
                # TODO: cena nie moze sie roznic za duzo od suggested...
                #  Decimal(d['suggested_price']) - Decimal(d['price']) and
                data['data']['items']
            )
        )

    async def get_sell_items_by_price(self, min_price: Decimal, max_price: Decimal) -> list:
        data = await self.get_bitskins_api('get_inventory_on_sale', params={
            'sort_by': 'created_at',  # {created_at|price|wear_value}
            'order': 'desc',
            'page': 1,
            'per_page': 480,
            'is_souvenir': '0',
            'min_price': str(min_price),
            'max_price': str(max_price),
        })

        # todo trzeba by dodac sprawdzenie ile danej broni jest na rynku
        return list(
            filter(
                lambda d: Decimal(d['suggested_price']) >= min_price and not d['is_mine'],
                # zdzarza sie tak ze skrzyne porobuja sprzedac za 100$, a jest warta 0.03$ :)
                data['data']['items']
            )
        )

    async def get_sell_item_by_name(self, weapon_name: str) -> Union[dict, None]:
        list_weapons = await self.get_sell_items_by_name(weapon_name)
        if not list_weapons:
            return None
        return list_weapons[0]

    async def buy_item_by_name_and_withdraw(self, weapon_name: str) -> str:
        data_item = await self.get_sell_item_by_name(weapon_name)
        if not data_item:
            raise AssertionError('item not in sale')

        data_buy = await self.get_buy_item({
            data_item['item_id']: data_item['price'],
        })
        if data_buy.get('status') != 'success':
            logging.critical('error on bitskins api: {}'.format(data_buy))
            raise AssertionError('error on bitskins api: {}'.format(data_buy))

        trade_tokens = data_buy.get('data', {}).get('trade_tokens', [])
        if not trade_tokens:
            logging.critical('not trade_tokens, error on bitskins api: {}'.format(data_buy))
            raise AssertionError('not trade_tokens, error on bitskins api: {}'.format(data_buy))

        return trade_tokens[0]

    async def get_items_for_withdrawal(self) -> Union[None, list]:
        data = await self.get_bitskins_api('get_my_inventory', params={
            'page': 1,
        })
        if not data:
            return None

        inventory = data.get('data', {}).get('pending_withdrawal_from_bitskins', {})
        status = inventory.get('status')
        if status != 'success':
            return None

        return inventory.get('items', [])

    async def withdraw_all_items_in_inventory(self) -> list:
        items = await self.get_items_for_withdrawal()
        list_items_ids = list(map(lambda d: d['item_id'], items))

        if not list_items_ids:
            return []

        data = await self.get_withdraw_item(list_items_ids)
        if data.get('status') != 'success':
            logging.critical('error on bitskins api: {}'.format(data))
            return []

        trade_tokens = data.get('data', {}).get('trade_tokens', [])
        if not trade_tokens:
            logging.critical('not trade_tokens, error on bitskins api: {}'.format(data))
            return []

        return trade_tokens

    async def get_reset_price_items(self):
        data = await self.get_bitskins_api('get_reset_price_items')
        if not data:
            return []

        items = data.get('data', {}).get('items', [])
        return [(item['market_hash_name'], item['item_id']) for item in items]

    async def get_items_inventory(self):
        response = await self.get_items_inventory_by_page(page=1)
        if response is None:
            return None

        items_ret = []
        items, max_page = response
        items_ret.extend(items)

        for page in range(2, max_page + 1):
            response = await self.get_items_inventory_by_page(page=page)
            if response is None:
                continue

            items, _ = response
            items_ret.extend(items)

        return items_ret

    async def get_items_inventory_by_page(self, page=1) -> Union[None, Tuple[list, int]]:
        data = await self.get_bitskins_api('get_my_inventory', {
            'page': page,
        })
        if not data:
            return None

        inventory = data.get('data', {}).get('bitskins_inventory', {})
        page = inventory.get('page', 1)  # todo
        max_per_page = 5000
        total_items = inventory.get('total_items', 0)
        max_page = int(math.ceil(total_items / max_per_page))

        status = inventory.get('status')
        if status != 'success':
            return None

        return inventory.get('items', []), max_page

    async def modify_sale_item(self, items):
        if not items[0]:
            return []

        ret_data = list()
        for index_start in range(0, len(items[0]), 50):
            data = await self.get_bitskins_api('modify_sale_item', {
                'item_ids': ','.join(items[0][index_start:index_start+50]),
                'prices': ','.join(items[1][index_start:index_start+50]),
            })
            ret_data.append(data)
            await asyncio.sleep(0.3)

        return ret_data

    async def sell_items(self, items):
        if not items:
            return None

        aa = []
        bb = []
        for a,b in items:
            aa.append(a)
            bb.append(b)

        return await self.get_bitskins_api('list_item_for_sale', {
            'item_ids': ','.join(aa),
            'prices': ','.join(bb),
        })

    # @fromorever_reset_on_raise(sleep=600)  # 10min
    # async def check_sell(self):
    #     items = await self.get_items_inventory()
    #     data = await self.modify_sale_item(items)
    #     logging.debug('get_items_inventory_new_price modify_sale_item: {}'.format(data))
    #     await asyncio.sleep(5)
    #
    #     items_reset = await self.get_reset_price_items()
    #     if items_reset:
    #         for market_hash_name, item_id in items_reset:
    #             price = self.get_price(market_hash_name)
    #             if not price:
    #                 logging.critical('brak ceny dla: {}'.format(market_hash_name))
    #                 continue
    #
    #             items[0].append(str(item_id))
    #             items[1].append(str(price))
    #
    #         data = await self.modify_sale_item(items)
    #         logging.critical('get_reset_price_items modify_sale_item: {}'.format(data))
    #
    #     # end
    #     bp_items, bp_descriptions = await self.get_backpack(730)
    #
    #     len_items = sum(map(lambda x: len(x), bp_items.values()))
    #     if len_items < 1:
    #         return
    #
    #     items = (
    #         [],  # asset_id
    #         [],  # price
    #     )
    #
    #     total_price = 0
    #     for market_hash_name, list_assets in bp_items.items():
    #         #if market_hash_name == 'AK-47 | Redline (Field-Tested)':
    #         #    continue
    #
    #         if len(items[0]) >= 50:
    #             break
    #
    #         price = self.get_price(market_hash_name)
    #         if not price:
    #             logging.critical('brak ceny dla: {}'.format(market_hash_name))
    #             continue
    #
    #         for asset_id in list_assets:
    #             if len(items[0]) >= 50:
    #                 break
    #
    #             items[0].append(str(asset_id))
    #             items[1].append(str(price))
    #
    #             total_price += float(price)
    #
    #     if not len(items[0]):
    #         return
    #
    #     data = await self.get_bitskins_api('list_item_for_sale', {
    #         'item_ids': ','.join(items[0]),
    #         'prices': ','.join(items[1]),
    #     })
    #     for trade_token in data.get('data', {}).get('trade_tokens', []):
    #         self.bitskins_accept_token.add(trade_token)
    #
    #     logging.info('Wysłano prośbę do bitskins z itemami za kwotę, {}'.format(total_price))



async def main():
    async with Bitskins() as s:
        pass
        # z = await s.buy_item_by_name_and_withdraw('MAC-10 | Candy Apple (Minimal Wear)')
        # pprint(z)
        # print(await s.get_withdraw_item([10250698718]))
        # print(await s.get_items_for_withdrawal())
        # print(await s.get_trade_details('6fa6a5be6073fb69', 'fd362f775e94d20c'))
        # print(await s.withdraw_all_items_in_inventory())
        # print(len(z))
        # 2fd44944bb512a49
        # 6fa6a5be6073fb69
        # BitSkins Trade Token: fd362f775e94d20c, Trade ID: 6fa6a5be6073fb69
        # {'status': 'success', 'data': {'items': [{'item_id': '10250698718', 'instance_id': '302028390', 'app_id': '730', 'price': '0.03', 'market_hash_name': 'MAC-10 | Candy Apple (Minimal Wear)', 'class_id': '310776718', 'context_id': '2'}], 'trade_tokens': ['fd362f775e94d20c']}}



if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
    loop.close()
