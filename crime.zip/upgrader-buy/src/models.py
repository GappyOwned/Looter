from typing import List, Union
import datetime
import time

import logging

from pymongo.results import UpdateResult, InsertOneResult
from pysteamweb import SteamIdParser

__all__ = (
    'APIModel',
    'TradeModel',

    'GameGameModel',
)


class MongoModelABC(object):
    model = ''

    def __init__(self, connection, db_name):
        self._connection = connection
        self._db_name = db_name

        self.collection = self.get_collection(self.model)

    def get_database(self):
        if not self._connection:
            raise AssertionError('connection not initialized')
        return self._connection['bot_v2_{}'.format(self._db_name)]

    def get_collection(self, name):
        return self.get_database()[name]


class APIModel(MongoModelABC):
    model = 'api'

    STATUS_SENT = 1
    STATUS_CLOSED = 2
    STATUS_EXPIRED = 3

    '''
        'items_their_assets': trade_document.get('items_their_assets'),
        'items_my_assets': trade_document.get('items_my_assets'),
    '''

    async def init(self, request_uid, response_channel, response_data, status=STATUS_SENT,
                   expire=1800) -> InsertOneResult:
        return await self.collection.insert_one({
            'request_uid': request_uid,
            'status': status,

            'response_channel': response_channel,
            'response_data': response_data,  # todo replace Decimal to Decimal128

            'created_at': datetime.datetime.now(),
            'when_expire_at': datetime.datetime.now() + datetime.timedelta(seconds=expire),
            'expire_at': None,
            'closed_at': None,
            'last_update': time.time(),
        })

    async def update_time(self, _id) -> UpdateResult:
        return await self.collection.update_one({
            '_id': _id,
        }, {
            '$set': {
                'last_update': time.time(),
            },
        })

    async def update_closed(self, _id) -> UpdateResult:
        return await self.collection.update_one({
            '_id': _id,
        }, {
            '$set': {
                'status': self.STATUS_CLOSED,
                'closed_at': datetime.datetime.now(),
                'last_update': time.time(),
            },
        })

    async def update_expired(self, _id) -> UpdateResult:
        return await self.collection.update_one({
            '_id': _id,
        }, {
            '$set': {
                'status': self.STATUS_EXPIRED,
                'expire_at': datetime.datetime.now(),
                'last_update': time.time(),
            },
        })

    async def get_by_status(self, status) -> list:
        ret = list()
        async for document in self.collection.find({
            'status': status,
        }):
            ret.append(document)

        return ret

    async def get_status_sent(self) -> list:
        return await self.get_by_status(self.STATUS_SENT)

    async def get_all(self) -> list:
        ret = list()
        async for document in self.collection.find():
            ret.append(document)

        return ret

    async def get_by_id(self, _id) -> Union[dict, None]:
        return await self.collection.find_one({
            '_id': _id,
        })


class TradeModel(MongoModelABC):
    model = 'trade'

    STATUS_TO_SEND = 0
    STATUS_SENT = 1
    STATUS_ACCEPTED_PENDING = 5  # bez assets
    STATUS_ERROR = 3
    STATUS_EXPIRED = 4
    STATUS_ACCEPTED = 2  # z assets

    TYPE_SEND = 0
    TYPE_RECEIVED = 1

    STATE_TO_ACCEPT = 1
    STATE_TO_CANCEL = 2

    async def init_send(self, trade_partner, trade_token, items, trade_message, request_uid, status=STATUS_TO_SEND,
                        expire=120, expire_request=120) -> InsertOneResult:
        return await self.collection.insert_one({
            'type': self.TYPE_SEND,

            'trade_id': None,
            'items': items,

            'is_check_their_assets': bool(items.get('their', [])),

            'items_my_assets': [],
            'items_their_assets': [],

            'trade_steam_id64': SteamIdParser(trade_partner).as_64(),
            'trade_token': trade_token,
            'trade_message': trade_message,

            'request_uid': request_uid,
            'status': status,

            'send_error': None,

            'created_at': datetime.datetime.now(),
            'when_expire_at': datetime.datetime.now() + datetime.timedelta(seconds=expire_request),
            'ttl_expire_send': expire,
            'ttl_expire_request': expire_request,
            'expire_at': None,
            'send_at': None,
            'accepted_at': None,
            'accepted_pending_at': None,
            'error_at': None,

            # 'trade_to_state': 0,  # not used
        })

    async def init_receive(self, trade_id, trade_partner, trade_token, items_my_assets, items_their_assets,
                           trade_message, request_uid, trade_to_state, send_error=None) -> InsertOneResult:
        return await self.collection.insert_one({
            'type': self.TYPE_RECEIVED,

            'trade_id': trade_id,

            'is_check_their_assets': bool(items_their_assets),

            'items_my_assets': items_my_assets,  # todo replace Decimal to Decimal128
            'items_their_assets': items_their_assets,  # todo replace Decimal to Decimal128

            'trade_steam_id64': SteamIdParser(trade_partner).as_64(),
            'trade_token': trade_token,
            'trade_message': trade_message,

            'request_uid': request_uid,
            'status': self.STATUS_SENT,

            'send_error': send_error,

            'created_at': datetime.datetime.now(),
            # 'when_expire_at': None,  # not used
            # 'ttl_expire_send': None,  # not used
            # 'ttl_expire_request': None,  # not used
            # 'expire_at': None,  # not used
            # 'send_at': None,  # not used
            'accepted_at': None,
            'accepted_pending_at': None,
            'error_at': None,

            'trade_to_state': trade_to_state,
            'trade_request_retry': 0,
            'is_request_delay': False,
        })

    async def update_trade_to_state(self, request_uid, trade_to_state) -> UpdateResult:
        # only in receive
        return await self.collection.update_one({
            'request_uid': request_uid,
        }, {
            '$set': {
                'trade_to_state': trade_to_state,
            },
        })

    async def update_inc_trade_state_retry(self, request_uid) -> UpdateResult:
        # only in receive
        return await self.collection.update_one({
            'request_uid': request_uid,
        }, {
            '$inc': {
                'trade_request_retry': 1,
            },
        })

    async def update_trade_state_delay(self, request_uid) -> UpdateResult:
        # only in receive
        return await self.collection.update_one({
            'request_uid': request_uid,
        }, {
            '$set': {
                'is_request_delay': True,
            },
        })

    async def update_sent(self, request_uid, trade_id, ttl_expire_send, items_my_assets,
                          items_their_assets) -> UpdateResult:
        return await self.collection.update_one({
            'request_uid': request_uid,
        }, {
            '$set': {
                'status': self.STATUS_SENT,
                'trade_id': str(trade_id),
                'items_my_assets': items_my_assets,  # todo replace Decimal to Decimal128
                'items_their_assets': items_their_assets,  # todo replace Decimal to Decimal128
                'send_at': datetime.datetime.now(),
                'when_expire_at': datetime.datetime.now() + datetime.timedelta(seconds=ttl_expire_send),
            },
        })

    async def update_error(self, request_uid, send_error) -> UpdateResult:
        return await self.collection.update_one({
            'request_uid': request_uid,
        }, {
            '$set': {
                'status': self.STATUS_ERROR,
                'send_error': send_error,
                'error_at': datetime.datetime.now()
            },
        })

    async def update_accepted_pending(self, request_uid) -> UpdateResult:
        return await self.collection.update_one({
            'request_uid': request_uid,
        }, {
            '$set': {
                'status': self.STATUS_ACCEPTED_PENDING,
                'accepted_pending_at': datetime.datetime.now()
            },
        })

    async def update_accepted(self, request_uid, items_their_assets) -> UpdateResult:
        return await self.collection.update_one({
            'request_uid': request_uid,
        }, {
            '$set': {
                'items_their_assets': items_their_assets,  # todo replace Decimal to Decimal128
                'status': self.STATUS_ACCEPTED,
                'accepted_at': datetime.datetime.now()
            },
        })

    async def update_expired(self, request_uid) -> UpdateResult:
        return await self.collection.update_one({
            'request_uid': request_uid,
        }, {
            '$set': {
                'status': self.STATUS_EXPIRED,
                'expire_at': datetime.datetime.now()
            },
        })

    async def get_by_status(self, status) -> list:
        cursor = self.collection.find({
            'type': self.TYPE_SEND,
            'status': status,
        })
        return await cursor.to_list(None)

    async def get_status_check(self) -> list:
        cursor = self.collection.find({
            'status': self.STATUS_SENT,
        })
        return await cursor.to_list(None)

    async def get_status_to_send(self) -> list:
        return await self.get_by_status(self.STATUS_TO_SEND)

    async def get_status_sent(self) -> list:
        return await self.get_by_status(self.STATUS_SENT)

    async def get_status_sent_by_my_asset_id(self, list_assets_ids: List[int]) -> list:
        cursor = self.collection.find({
            'type': self.TYPE_SEND,
            'status': {
                '$in': [
                    self.STATUS_TO_SEND,
                    self.STATUS_SENT,
                ]
            },
            'items_my_assets.my_asset_id': {
                '$in': list_assets_ids
            }
        })
        return await cursor.to_list(None)

    async def get_status_accepted_by_my_asset_id(self, list_assets_ids: List[int]) -> list:
        cursor = self.collection.find({
            'status': self.STATUS_ACCEPTED,
            'items_their_assets.my_asset_id': {
                '$in': list_assets_ids
            }
        })
        return await cursor.to_list(None)

    async def get_status_accepting_pending(self) -> list:
        cursor = self.collection.find({
            'status': self.STATUS_ACCEPTED_PENDING,
        })
        return await cursor.to_list(None)

    async def get_all(self) -> list:
        cursor = self.collection.find({})
        return await cursor.to_list(None)

    async def get_by_request_uid(self, r_id) -> Union[dict, None]:
        return await self.collection.find_one({
            'request_uid': r_id,
        })

    async def get_by_trade_id(self, trade_id: int) -> Union[dict, None]:
        return await self.collection.find_one({
            'trade_id': trade_id,
        })

    async def get_receive_not_done_count(self) -> int:
        return await self.collection.find({
            'type': self.TYPE_RECEIVED,
            'is_request_delay': False,
            'status': self.STATUS_SENT,
        }).count()


class GameGameModel(MongoModelABC):
    model = 'game_game'

    STATUS_TRADE_TO_SEND = 1  # trade z itemem do pobrania od typa
    STATUS_TRADE_REQUEST = 2
    STATUS_TRADE_SENT = 3

    STATUS_TO_BUY = 4  # item do kupienia na bitskins
    STATUS_WAIT_TRADE = 5  # item kupiony ale czekamy na trade
    STATUS_TO_SEND = 6  # trade, item gotowy do wysylki
    STATUS_SENT = 7  # trade wyslany do ziomka
    STATUS_ACCEPTED = 8  # trade zaakceptowany
    STATUS_CANCEL = 9  # czas na wysylke minal, lub za duzo bledow

    WINNER_STATUS_TO_SEND = 1  # do wyslania
    WINNER_STATUS_REQUEST = 5  # gdy wysylamy do typa, moze byc bug tutaj zwiazany z race-condition np. gdy padnie bot, a nie oznaczy sobie
    WINNER_STATUS_SENT = 2  # gdy wyslany do typka
    WINNER_STATUS_ACCEPTED = 3  # gdy typek zaakceptowal
    WINNER_STATUS_CLOSED = 4  # gdy przekroczy jakis czas bo np. user nie odebral lub nie mogl wyslac przez 24h

    async def init(
        self,
        game_id: int,
        steam_id: str,
        assets_items: List[int],
        market_hash_name: str,
        sell_trade_message: str,
        winner_trade_message: str,
        when_expire: datetime.datetime,
        extend_data: dict,
    ) -> InsertOneResult:
        return await self.collection.insert_one({
            '_id': game_id,

            'extend_data': extend_data,

            'created_at': datetime.datetime.now(),
            'created_at_timestamp': datetime.datetime.now().timestamp(),

            'when_expire': when_expire,

            'status': self.STATUS_TRADE_TO_SEND,

            'steam_id': str(steam_id),
            'market_hash_name': market_hash_name,

            'sell_trade_message': sell_trade_message,
            'sell_assets_items': assets_items,
            'sell_trade_data': None,  # pozniej
            'sell_trade_id': None,  # pozniej

            'sell_unique_id': None,  # zerowac gdy chcemy wyslac nowy trade
            'sell_timestamp': 0,  # nie trzeba zerowac
            'sell_created_timestamp': datetime.datetime.now().timestamp(),

            'buy_bitskins_when_was': None,  # kiedy zostal kupiony
            'buy_bitskins_token': None,  # ustawiany gdy kupimy jaki item
            'buy_bitskins_timestamp': 0,  # event checker
            'buy_bitskins_trade_id': None,  # pozniej
            'buy_trade_id': None,  # pozniej
            'buy_trade_data': None,  # pozniej
            'buy_trade_history': [],

            'buy_next_check_timestamp': 0,  # kiedy ma ponownie sprobowac kupic
            'buy_created_at': None,  # potrzebne do sprawdzenia jak dlugo ma kupowac

            'buying_error': None,

            'winner_trade_message': winner_trade_message,
            'winner_trade_history': [],
            'winner_trade_data': None,  # pozniej
            'winner_trade_id': None,  # pozniej

            'winner_unique_id': None,  # zerowac gdy chcemy wyslac nowy trade
            'winner_timestamp': 0,  # nie trzeba zerowac
            'winner_status': 0,  # zerowac
            'winner_send_timestamp': 0,  # kiedy moze ponowic
            'winner_created_timestamp': None,

            'send_sync': True,
        })

    async def update_expired(self):
        # return await self.collection.update_many({
        #     'status': {'$in': [self.STATUS_TO_SEND, self.STATUS_TO_BUY, self.STATUS_WAIT_TRADE]},
        #     'buy_created_at': {'$lt': (datetime.datetime.now() - datetime.timedelta(days=1)).timestamp()},
        # }, {
        #     '$set': {
        #         'status': self.STATUS_CANCEL,
        #     },
        # })
        # todo kiedy ma oznaczac ze wygaslo?
        pass

    async def update_buy_trade_uid(
        self,
        bitskins_token: str,
        bitskins_trade_id: str,
        event_timestamp: int,
        trade_id: int,
        trade_data: dict
    ):
        logging.info('start update_buy_trade_uid, bitskins_token={}, data={}'.format(bitskins_token, trade_data))
        data = {}

        if trade_data['status'] == TradeModel.STATUS_ACCEPTED:
            data = {
                '$set': {
                    'buy_bitskins_trade_id': bitskins_trade_id,
                    'buy_bitskins_timestamp': event_timestamp,
                    'buy_trade_id': trade_id,
                    'buy_trade_data': trade_data,

                    'status': self.STATUS_TO_SEND,
                    'winner_status': self.WINNER_STATUS_TO_SEND,  # ustawienie ze mozna wyslac wygrana
                    'winner_created_timestamp': datetime.datetime.now().timestamp(),

                    'send_sync': True,
                }
            }
        elif trade_data['status'] == TradeModel.STATUS_ACCEPTED_PENDING:
            data = {
                '$set': {
                    'buy_bitskins_trade_id': bitskins_trade_id,
                    'buy_bitskins_timestamp': event_timestamp,
                    'buy_trade_id': trade_id,
                    'buy_trade_data': trade_data,

                    'send_sync': True,
                }
            }
        elif trade_data['status'] in (TradeModel.STATUS_ERROR, TradeModel.STATUS_EXPIRED):
            data = {
                '$set': {
                    'buy_bitskins_timestamp': event_timestamp,

                    # clear
                    'buy_bitskins_trade_id': None,
                    'buy_trade_id': None,
                    'buy_trade_data': None,

                    'send_sync': True,
                },

                # history
                '$push': {
                    'buy_trade_history': trade_data,
                },
            }

        if not data:
            raise AssertionError('brak danych do aktualizacji')

        return await self.collection.update_one({
            'buy_bitskins_token': bitskins_token,
            'buy_bitskins_timestamp': {'$lt': event_timestamp},
            'status': self.STATUS_WAIT_TRADE,
        }, data)

    def get_trade_to_buy(self):  # FIXME return type
        return self.collection.find({
            'status': self.STATUS_TO_BUY,
            'buy_next_check_timestamp': {'$lt': datetime.datetime.now().timestamp()},
            'buy_created_at': {'$gt': (datetime.datetime.now() - datetime.timedelta(days=1)).timestamp()},
        })

    async def update_trade_was_bought(self, game_id: int, buy_bitskins_token: str) -> UpdateResult:
        return await self.collection.update_one({
            '_id': game_id,
            'status': self.STATUS_TO_BUY,
        }, {
            '$set': {
                'buy_bitskins_token': buy_bitskins_token,
                'buy_bitskins_when_was': datetime.datetime.now(),
                'status': self.STATUS_WAIT_TRADE,

                'send_sync': True,
            },
        })

    async def update_trade_next_buy_check(self, game_id: int, buying_error: str) -> UpdateResult:
        return await self.collection.update_one({
            '_id': game_id,
            'status': self.STATUS_TO_BUY,
        }, {
            '$set': {
                'buy_next_check_timestamp': (datetime.datetime.now() + datetime.timedelta(minutes=5)).timestamp(),
                'buying_error': buying_error,

                'send_sync': True,
            },
        })

    #####
    async def update_winner_trade_uid(self, unique_id: str, event_timestamp: int, trade_id: Union[int, None],
                                      trade_data: dict) -> UpdateResult:
        winner_status = {
            TradeModel.STATUS_TO_SEND: self.WINNER_STATUS_REQUEST,
            TradeModel.STATUS_SENT: self.WINNER_STATUS_SENT,
            TradeModel.STATUS_ACCEPTED_PENDING: self.WINNER_STATUS_ACCEPTED,
            TradeModel.STATUS_ERROR: self.WINNER_STATUS_CLOSED,
            TradeModel.STATUS_EXPIRED: self.WINNER_STATUS_CLOSED,
            TradeModel.STATUS_ACCEPTED: self.WINNER_STATUS_ACCEPTED,
        }.get(trade_data['status'], None)
        status = {
            TradeModel.STATUS_TO_SEND: self.STATUS_TO_SEND,
            TradeModel.STATUS_SENT: self.STATUS_SENT,
            TradeModel.STATUS_ACCEPTED_PENDING: self.STATUS_ACCEPTED,
            TradeModel.STATUS_ERROR: self.STATUS_TO_SEND,
            TradeModel.STATUS_EXPIRED: self.STATUS_TO_SEND,
            TradeModel.STATUS_ACCEPTED: self.STATUS_ACCEPTED,
        }.get(trade_data['status'], None)

        if winner_status is None or status is None:
            raise NotADirectoryError('unknown winner_status trade type')

        data = {}
        if winner_status == self.WINNER_STATUS_CLOSED:
            # document = await self.collection.find_one({
            #     'winner_unique_id': unique_id,
            #     'winner_timestamp': {'$lt': event_timestamp},
            # })
            data = {
                '$set': {
                    'status': self.STATUS_TO_SEND,
                    'winner_status': self.WINNER_STATUS_TO_SEND,
                    'winner_timestamp': event_timestamp,

                    # clear
                    'winner_trade_id': None,
                    'winner_trade_data': None,
                    'winner_unique_id': None,
                    'winner_send_timestamp': (datetime.datetime.now() + datetime.timedelta(minutes=5)).timestamp(),
                    # nastepne wyslanie za 5min

                    'send_sync': True,
                },

                # history
                '$push': {
                    'winner_trade_history': trade_data,
                },
            }
        else:
            data = {
                '$set': {
                    'winner_timestamp': event_timestamp,
                    'winner_status': winner_status,
                    'winner_trade_id': trade_id,
                    'winner_trade_data': trade_data,
                    'status': status,

                    'send_sync': True,
                }
            }

        logging.info('start update_winner_trade_uid, unique_id={}, data={}'.format(unique_id, data))
        return await self.collection.update_one({
            'winner_unique_id': unique_id,
            'winner_timestamp': {'$lt': event_timestamp},
        }, data)

    async def update_winner_request(self, game_id: int, request_uid: str) -> UpdateResult:
        return await self.collection.update_one({
            '_id': game_id,
            'winner_unique_id': None,
        }, {
            '$set': {
                'winner_status': self.WINNER_STATUS_REQUEST,
                'winner_unique_id': request_uid,

                'send_sync': True,
            },
        })

    def get_winner_to_send(self):  # FIXME return type
        return self.collection.find({
            'winner_status': self.WINNER_STATUS_TO_SEND,
            'winner_send_timestamp': {'$lt': datetime.datetime.now().timestamp()},
            'winner_created_timestamp': {'$gt': (datetime.datetime.now() - datetime.timedelta(days=1)).timestamp()},
        })

    async def get_by_game_id(self, game_id: int) -> Union[None, dict]:
        return await self.collection.find_one({
            '_id': game_id,
        })

    #####
    async def update_sell_trade_uid(self, unique_id: str, event_timestamp: int, trade_id: Union[int, None], trade_data: dict) -> UpdateResult:
        status = {
            TradeModel.STATUS_TO_SEND: self.STATUS_TRADE_TO_SEND,
            TradeModel.STATUS_SENT: self.STATUS_TRADE_SENT,
            TradeModel.STATUS_ACCEPTED_PENDING: self.STATUS_TO_BUY,
            TradeModel.STATUS_ERROR: self.STATUS_CANCEL,
            TradeModel.STATUS_EXPIRED: self.STATUS_CANCEL,
            TradeModel.STATUS_ACCEPTED: self.STATUS_TO_BUY,  # drugie potwierdzenie moze nie wpasc :/
        }.get(trade_data['status'], None)

        if status is None:
            raise NotADirectoryError('unknown winner_status trade type')

        data = {}
        if status == self.STATUS_CANCEL:
            data = {
                '$set': {
                    'status': self.STATUS_CANCEL,
                    'sell_trade_data': trade_data,
                    'sell_timestamp': event_timestamp,

                    'send_sync': True,
                },
            }
        elif status == self.STATUS_TO_BUY:
            doc = await self.collection.find_one({
                'sell_unique_id': unique_id,
            })
            if doc['market_hash_name'] == '':
                status = self.STATUS_ACCEPTED

            data = {
                '$set': {
                    'status': status,
                    'sell_timestamp': event_timestamp,
                    'sell_trade_id': trade_id,
                    'sell_trade_data': trade_data,
                    'buy_created_at': datetime.datetime.now().timestamp(),

                    'send_sync': True,
                },
            }
        else:
            data = {
                '$set': {
                    'sell_timestamp': event_timestamp,
                    'sell_trade_id': trade_id,
                    'sell_trade_data': trade_data,
                    'status': status,

                    'send_sync': True,
                }
            }

        logging.info('start update_sell_trade_uid, unique_id={}, data={}'.format(unique_id, data))
        return await self.collection.update_one({
            'status': {'$in': [self.STATUS_TRADE_TO_SEND, self.STATUS_TRADE_SENT, self.STATUS_TRADE_REQUEST]},
            'sell_unique_id': unique_id,
            'sell_timestamp': {'$lt': event_timestamp},
        }, data)

    async def update_sell_request(self, game_id: int, request_uid: str) -> UpdateResult:
        return await self.collection.update_one({
            '_id': game_id,
            'sell_unique_id': None,
            'status': self.STATUS_TRADE_TO_SEND,
        }, {
            '$set': {
                'status': self.STATUS_TRADE_REQUEST,
                'sell_unique_id': request_uid,

                'send_sync': True,
            },
        })

    def get_sell_to_send(self):  # FIXME return type
        return self.collection.find({
            'status': self.STATUS_TRADE_TO_SEND,
            # 'sell_send_timestamp': {'$lt': datetime.datetime.now().timestamp()},
            'sell_created_timestamp': {'$gt': (datetime.datetime.now() - datetime.timedelta(minutes=5)).timestamp()},
        })

    def get_send_sync(self):  # FIXME return type
        return self.collection.find({
            'send_sync': True,
        })

    async def update_send_sync(self, game_id: int) -> UpdateResult:
        return await self.collection.update_one({
            '_id': game_id,
            'send_sync': True,
        }, {
            '$set': {
                'send_sync': False,
            },
        })
