import asyncio
import json
import traceback
import types
import uuid
import re
from typing import Dict, List, Tuple
from typing import Set
from typing import Union

import logging

import itertools

import datetime
from pysteamweb import SteamIdParser
from Crypto.Random import random

from models import GameGameModel, TradeModel
from utils import Decimal, cache, LazyJSONEncoder
from utils import forever_reset_on_raise
from bitskins import Bitskins

__all__ = (
    'GameManager',
)


class ErrorMessage(Exception):
    def __init__(self, message: str):
        self._message = message

    @property
    def message(self) -> str:
        return self._message


class GameManager(object):
    def __init__(self, bot_manager):
        self.bot_manager = bot_manager
        self._connection = self.bot_manager._connection
        self.bitskins = Bitskins()

        self.model_game = None  # type: Union[None, GameGameModel]
        self.db_users = dict()  # type: Dict[str, dict]

        self.bot_trade_url = None  # type: Union[str, None]

        self.lock_incoming = True  # type: bool
        self._trades_in_pre_queue = set()  # type: Set[int]
        self._lock_game_in_winner = set()  # type: Set[int]

        self._db_price = dict()  # type: Dict[str, Decimal]
        self._db_weapon_info = dict()  # type: Dict[str, dict]

        self._db_sale_tokens = set()

    def handle_fake_api(self):
        # todo extend to dynamic setting
        setattr(self.bot_manager, 'task_w4_get_game', types.MethodType(self.task_w4_get_game(), self.bot_manager))
        setattr(self.bot_manager, 'task_w4_make_game', types.MethodType(self.task_w4_make_game(), self.bot_manager))
        setattr(self.bot_manager, 'task_w4_get_roller', types.MethodType(self.task_w4_get_roller(), self.bot_manager))
        setattr(self.bot_manager, 'task_w4_get_balance', types.MethodType(self.task_w4_get_balance(), self.bot_manager))
        setattr(self.bot_manager, 'task_w4_sell_bitskins', types.MethodType(self.task_w4_sell_bitskins(), self.bot_manager))

    def task_w4_get_game(self):
        async def _inner(self_bot, game_id):
            game_id = int(game_id)
            game_data = await self.model_game.get_by_game_id(game_id)
            return {
                'game': game_data,
            }

        return _inner

    def task_w4_get_roller(self):
        async def _inner(self_bot, steam_id: str, asset_id: str, tickets: list):
            return await self.get_weapons_to_roll(steam_id=steam_id, asset_id=int(asset_id), tickets=tickets)

        return _inner

    def task_w4_get_balance(self):
        async def _inner(self_bot):
            return {
                'price': await self.get_bitskins_balance(),
            }

        return _inner

    def task_w4_sell_bitskins(self):
        async def _inner(self_bot):
            await self._sell_bitskins()
            return {
                'status': True,
            }

        return _inner

    def task_w4_make_game(self):
        async def _inner(self_bot, game_id: int, steam_id: str, assets_items: List[str], market_hash_name: str, sell_trade_message: str, winner_trade_message: str, when_expire: int, extend_data: dict):
            game_id = int(game_id)
            await self.model_game.init(
                game_id=game_id,
                steam_id=steam_id,
                market_hash_name=market_hash_name,
                sell_trade_message=sell_trade_message,
                winner_trade_message=winner_trade_message,
                assets_items=list(map(lambda s: int(s), assets_items)),
                when_expire=datetime.datetime.fromtimestamp(when_expire),
                extend_data=extend_data,
            )
            return {
                'unique_id': str(game_id),
            }

        return _inner

    async def connect(self):
        self.model_game = GameGameModel(self._connection, 'game_v1')

        asyncio.ensure_future(self.worker_check_pending_inventory())
        asyncio.ensure_future(self.worker_event())
        asyncio.ensure_future(self.worker_winner_trade())
        asyncio.ensure_future(self.worker_sell_trade())
        asyncio.ensure_future(self.worker_buy_trade())
        asyncio.ensure_future(self.worker_check_expired())
        asyncio.ensure_future(self.worker_check_expired2())
        asyncio.ensure_future(self.worker_update_db())
        asyncio.ensure_future(self.worker_sell_bitskins())
        # asyncio.ensure_future(self.worker_send_api())

        self.bot_trade_url = await self.bot_manager.bot_obj.get_trade_url(timeout=60)
        # self.emit('trade_url', {
        #     'trade_url': self.bot_trade_url,
        # })
        self.handle_fake_api()

    @forever_reset_on_raise(sleep=60)
    async def worker_update_db(self):
        list_weapons = await self.update_stable_price()

        a = dict()
        b = dict()
        for weapon in list_weapons:
            a[weapon['market_hash_name']] = Decimal(str(weapon['price']))
            b[weapon['market_hash_name']] = weapon

        self._db_price = a
        self._db_weapon_info = b

        # MOCK!!!!!
        def get_price(self_bot, market_hash_name):
            return self._db_price.get(market_hash_name)

        setattr(self.bot_manager.bot_obj, 'get_price', types.MethodType(get_price, self.bot_manager.bot_obj))
        # MOCK!!!!!

    async def update_stable_price(self):
        list_weapons = (await self.bot_manager.bot_obj.session.send_request(
            url='http://proxy.dream.ovh/api/v1/get/prices/crimewheel',
            is_post=False,
            is_json=True,
            timeout=10,
        ))['response']

        def _filter_weapon(d):
            tags = d.get('tags', {})

            if tags.get('type') == 'Sticker':
                # strickery
                return True
            elif tags.get('type') == 'Knife':
                # kosy bez statrak
                if tags.get('quality') == 'StatTrak™':
                    return False
                else:
                    return True
            elif tags.get('type') in ('Rifle', 'Machinegun', 'Sniper Rifle', 'Pistol', 'Shotgun',):
                # bronie bez souvenirow
                if tags.get('quality') == 'Souvenir':
                    return False
                else:
                    return True

            return False

        def _filter_available(d):
            if d.get('quantity') > 5 and d.get('tags') and d.get('img') and float(d.get('price', '0')) > 0:
                return True

            return False

        list_weapons = filter(
            _filter_weapon,
            filter(
                _filter_available,
                list_weapons
            )
        )
        return list(list_weapons)

    async def set_redis(self, *args, **kwargs):
        return await self.bot_manager.set_redis(*args, **kwargs)

    async def get_redis(self, *args, **kwargs):
        return await self.bot_manager.get_redis(*args, **kwargs)

    async def del_redis(self, *args, **kwargs):
        return await self.bot_manager.del_redis(*args, **kwargs)

    @cache('bitskins_balance', 5, [])
    async def get_bitskins_balance(self) -> Decimal:
        try:
            price_obj = await self.bitskins.get_balance_available()
            price = Decimal(str(price_obj))
        except:
            logging.debug('error on get_bitskins_balance')
            price = None

        return price

    async def get_weapons_to_roll(self, steam_id: str, asset_id: int, tickets: List[Tuple[str, str, str]]):
        weapon_user, (list_price_mul, dict_range_by_weapons) = await self.get_weapons_choice_by_asset(steam_id=steam_id, asset_id=asset_id, is_must_all=True)

        # max dwa miejsca po przecinku!
        settings_roll = []
        for real_change, real_mul, fake_chance in tickets:
            settings_roll.append((Decimal(real_change), Decimal(real_mul), fake_chance))

        tickets = []
        _min_ticket = 1
        _sum_percent = 0
        for real_percent, real_mul, fake_percent in settings_roll:
            _diff_ticket = int(float(str(real_percent * Decimal('100'))))
            _sum_percent += _diff_ticket

            tickets.append((
                (_min_ticket, _sum_percent),
                real_mul,
                fake_percent,
            ))
            _min_ticket += _diff_ticket

        if (_sum_percent / 100) != 100:
            raise RuntimeError('ticker is mismatch with 100%, eq: {}'.format(_sum_percent / 100))

        win_ticket = random.randint(tickets[0][0][0], tickets[-1][0][1])

        one_weapon_per_ticker = []
        weapon_win = None
        weapon_win_index = None
        weapon_win_mul = None

        for (_min, _max), muller, str_fake_percent in tickets:
            if muller == Decimal('0'):
                one_weapon_per_ticker.append({
                    'img': 'https://crimewheel.com/static/images/nothing.png',
                    'market_hash_name': '',
                    'price': '0',
                    'percent': str(str_fake_percent),
                })
            else:
                random_weapon = random.choice(dict_range_by_weapons.get(int(muller * Decimal('1000'))))
                one_weapon_per_ticker.append({
                    'img': random_weapon['img'] + '96x96',
                    'market_hash_name': random_weapon['market_hash_name'],
                    'price': str(random_weapon['price']),
                    'percent': str(str_fake_percent),
                })

            if _min <= win_ticket <= _max:
                weapon_win = one_weapon_per_ticker[-1]
                weapon_win_index = len(one_weapon_per_ticker) - 1
                weapon_win_mul = muller

        can_win_buy = False
        if weapon_win['market_hash_name'] == '':
            can_win_buy = True
        else:
            bitskins_price = await self.get_bitskins_balance()
            if bitskins_price is None:
                can_win_buy = False
            else:
                weapon_win_price = Decimal(str(weapon_win['price'])) * Decimal('1.5') # 50% zapasu musi byc
                if bitskins_price > weapon_win_price:
                    can_win_buy = True
                else:
                    can_win_buy = False

        return {
            'unique_id': str(uuid.uuid4()),

            'tickets': tickets,
            'win_ticket': win_ticket,

            'can_win_buy': can_win_buy,

            'weapon_user': weapon_user,
            'weapon_win': weapon_win,
            'weapon_win_index': weapon_win_index,
            'weapon_win_mul': weapon_win_mul,

            'list_weapons': one_weapon_per_ticker,
        }

    async def get_weapons_choice_by_asset(self, steam_id: str, asset_id: int, is_must_all=True) -> Tuple[dict, Tuple[List[Decimal], Dict[int, List[dict]]]]:
        dict_items_by_asset = await self.bot_manager.get_their_backpack(steam_id=steam_id, by_group=2)
        weapon_info = dict_items_by_asset.get(asset_id)
        if weapon_info is None:
            raise AssertionError('You don\'t have this item?')

        r = await self.get_weapons_choice_by_name(
            market_hash_name=weapon_info['market_hash_name'],
            is_must_all=is_must_all
        )
        return weapon_info, r

    async def get_weapons_choice_by_name(self, market_hash_name, is_must_all=True) -> Tuple[List[Decimal], Dict[int, List[dict]]]:
        # - Skin 2x droższy - 30%  +-
        # - Skin 0.5x droższy - 30%
        # - Skin 6x droższy - 1%
        # - Nic - 39%
        base_price = self._db_price.get(market_hash_name)
        if base_price is None:
            raise AssertionError('Your item have no price')

        list_price_mul = [
            # mnoznik, procent glebokosci
            (Decimal('0.5'), Decimal('0.1')),
            (Decimal('2'), Decimal('0.1')),
            (Decimal('6'), Decimal('0.1')),
        ]
        _list_price_mul = [
            a
            for a, b in list_price_mul
        ]

        list_price_ranges = []
        for price_mul, price_depth_percent in list_price_mul:
            _price_base = base_price * price_mul
            _price_diff = _price_base * price_depth_percent

            _price_low = _price_base - _price_diff
            _price_high = _price_base + _price_diff

            if _price_low <= Decimal('0.03'):
                _price_low = Decimal('0.03')

            if _price_high <= Decimal('0.03'):
                _price_high = Decimal('0.03')

            if _price_base <= Decimal('0.03'):
                _price_base = Decimal('0.03')

            list_price_ranges.append((_price_low, _price_base))

        dict_weapon_by_ranges = dict()
        for weapon_name, weapon_price in self._db_price.items():
            _assigned_range = None

            for index, (_low, _high) in enumerate(list_price_ranges):
                if _low <= weapon_price <= _high:
                    _assigned_range = int(list_price_mul[index][0] * Decimal('1000'))
                    break

            if _assigned_range is None:
                continue

            dict_weapon_by_ranges.setdefault(_assigned_range, list()).append(self._db_weapon_info[weapon_name])

        if is_must_all:
            if len(list(dict_weapon_by_ranges.keys())) != len(_list_price_mul):
                logging.debug('Not all items can be reach, dict_weapon_by_ranges={}, _list_price_mul={} list_price_ranges={}'.format(
                    list(dict_weapon_by_ranges.keys()),
                    _list_price_mul,
                    list_price_ranges
                ))
                raise AssertionError('Not all items can be reach')

        return _list_price_mul, dict_weapon_by_ranges

    # @forever_reset_on_raise(sleep=32)
    # async def worker_send_api(self):
    #     logging.debug('check worker_send_api')
    #     async for document in self.model_game.get_send_request_api():
    #         game_id = document['_id']
    #         logging.debug('check start worker_send_api, game_id={}'.format(game_id))
    #         await self.send_to_php_round_data(game_id)
    #         await self.model_game.update_send_request_api(game_id)
    #         logging.debug('check end worker_send_api, game_id={}'.format(game_id))
    #
    # async def send_to_php_round_data(self, game_id):
    #     round_document = await self.model_game.get_by_game_id(game_id)
    #     bets_document = await self.model_bet.get_list_by_game_id(game_id)
    #
    #     dict_users = dict()
    #     for document in bets_document:
    #         sid = document['steam_id']
    #         dict_users.setdefault(sid, {
    #             'steam_id': str(sid),
    #             'is_winner': str(round_document['winner']) == str(sid),
    #             'round_id': game_id,
    #             'round_hash': str(round_document['hash']),
    #             'trades': [],
    #             'full_price': 0.0,
    #             'chance': 0,
    #         })
    #
    #         sum_price = 0
    #         list_items = list()
    #         for item in document['items']:
    #             sum_price += float(str(item['price']))
    #             list_items.append({
    #                 'market_hash_name': item['market_hash_name'],
    #                 'price': float(str(item['price'])),
    #             })
    #
    #         dict_users[sid]['trades'].append({
    #             'trade_id': document['_id'],
    #             'full_price': sum_price,
    #             'items': list_items,
    #         })
    #         dict_users[sid]['full_price'] += sum_price
    #
    #     sum_prices = sum([user['full_price'] for user in dict_users.values()])
    #     for sid in dict_users.keys():
    #         dict_users[sid]['chance'] = dict_users[sid]['full_price'] / sum_prices
    #
    #     await self.bot_manager.bot_obj.session.send_request(
    #         url='https://csgopeanut.com/japi/round',
    #         data={
    #             'magic_data': json.dumps(list(dict_users.values())),
    #         },
    #         is_post=True,
    #         is_json=False,
    #         timeout=10,
    #     )

    #######################
    async def sent_on_trade_data(self, all_data: dict) -> bool:
        '''
        'event_id': str(document['_id']),
        'event_created_at': document['created_at'].timestamp(),
        'request_uid': str(document['request_uid']),
        'timestamp': time.time(),
        'data': document['response_data'],

                'type': trade_document['type'],
                'trade_steam_id64': trade_document.get('trade_steam_id64'),

                'trade_id': trade_document['trade_id'],
                'items': trade_document['items'],

                'is_check_their_assets': trade_document['is_check_their_assets'],
                'items_their_in_my_eq': {str(data['their_asset_id']): data['my_asset_id'] for data in trade_document['items_their_assets']},

                'items_their_assets': trade_document['items_their_assets'],
                'items_my_assets': trade_document['items_my_assets'],

                'status': trade_document['status'],
                'send_error': trade_document['send_error'],

                'created_at': trade_document['created_at'],
                'expire_at': trade_document['expire_at'],
                'send_at': trade_document['send_at'],
                'accepted_at': trade_document['accepted_at'],
                'accepted_pending_at': trade_document['accepted_pending_at'],
                'error_at': trade_document['error_at'],
        '''
        request_uid = all_data['request_uid']
        event_created_at = all_data['event_created_at']
        trade_data = all_data['data']
        # jak wiedziec z jakiej to gry??
        trade_message = str(trade_data.get('trade_message', ''))
        trade_type = None
        if trade_message.startswith('] '):
            trade_type = 1  # wyslany trade do typa
        elif trade_message.startswith('} '):
            trade_type = 2  # wyslany trade z wygrana

        if not trade_type:
            # todo alert to admin - wtf?
            logging.critical('stop on_winner_trade_data, all_data={}, not trade_type'.format(all_data))
            return True

        if trade_type == 2:
            res = await self.model_game.update_winner_trade_uid(
                request_uid,
                event_created_at,
                trade_data['trade_id'],
                trade_data,
            )
            if res.modified_count == 0:
                # todo alert to admin - wtf?
                logging.critical('stop on_winner_trade_data, all_data={}, res.modified_count == 0'.format(all_data))
                return True

            status = trade_data['status']
            steam_id = str(trade_data['trade_steam_id64'])
            if status == TradeModel.STATUS_SENT:
                # self.emit_message(steam_id, -1, '[801] We sent trade to you.')

                self.emit_to(steam_id, 'trade_sent', {
                    'trade_id': trade_data['trade_id'],
                    'game_id': trade_data.get('trade_message', ''),
                })
            elif status in (TradeModel.STATUS_ERROR, TradeModel.STATUS_EXPIRED):
                # self.emit_message(steam_id, 2, '[803] Trade has error. Error: {}'.format(trade_data['send_error']))
                pass
            elif status in (TradeModel.STATUS_ACCEPTED_PENDING, TradeModel.STATUS_ACCEPTED):
                # self.emit_message(steam_id, 0, '[802] You accept trade.')
                pass

            return True
        elif trade_type == 1:
            res = await self.model_game.update_sell_trade_uid(
                request_uid,
                event_created_at,
                trade_data['trade_id'],
                trade_data,
            )
            if res.modified_count == 0:
                # todo alert to admin - wtf?
                res2 = await self.model_game.collection.update_one({
                    'sell_unique_id': request_uid,
                    'sell_timestamp': {'$lt': event_created_at},
                }, {
                    '$set': {
                        'sell_timestamp': event_created_at,
                        'sell_trade_data': trade_data,
                    }
                })

                logging.critical('stop on_winner_trade_data, all_data={}, res.modified_count == 0'.format(all_data))
                return True

            status = trade_data['status']
            steam_id = str(trade_data['trade_steam_id64'])
            if status == TradeModel.STATUS_SENT:
                # self.emit_message(steam_id, -1, '[801] We sent trade to you.')

                self.emit_to(steam_id, 'trade_sent', {
                    'trade_id': trade_data['trade_id'],
                    'game_id': trade_data.get('trade_message', ''),
                })
            elif status in (TradeModel.STATUS_ERROR, TradeModel.STATUS_EXPIRED):
                # self.emit_message(steam_id, 2, '[803] Trade has error. Error: {}'.format(trade_data['send_error']))
                pass
            elif status in (TradeModel.STATUS_ACCEPTED_PENDING, TradeModel.STATUS_ACCEPTED):
                # self.emit_message(steam_id, 0, '[802] You accept trade.')
                doc = await self.model_game.collection.find_one({
                    'sell_unique_id': request_uid,
                })
                self.emit_to(steam_id, 'roller', {
                    'list_weapons': doc['extend_data']['list_weapons'],
                    'weapon_win_index': doc['extend_data']['weapon_win_index'],
                })

                if float(doc['extend_data']['weapon_win_mul']) > 0.2:
                    self.emit('spin', {
                        'muller': float(doc['extend_data']['weapon_win_mul']),
                        'from': {
                            'market_hash_name': doc['extend_data']['weapon_user']['market_hash_name'],
                            'price': str(doc['extend_data']['weapon_user']['price']),
                            'img': 'https://steamcommunity-a.akamaihd.net/economy/image/{}'.format(
                                doc['extend_data']['weapon_user']['icon_url'] or doc['extend_data']['weapon_user']['icon_url_large'],
                            ),
                        },
                        'to': {
                            'market_hash_name': doc['extend_data']['weapon_win']['market_hash_name'] if doc['extend_data']['weapon_win'] else '',
                            'price': str(doc['extend_data']['weapon_win']['price']) if doc['extend_data']['weapon_win'] else '0',
                            'img': doc['extend_data']['weapon_win']['img'] if doc['extend_data']['weapon_win'] else '',
                        },
                    }, timeout=9)

            return True

        return True

    @forever_reset_on_raise(sleep=300)
    async def worker_check_expired(self):
        logging.debug('start worker_check_expired')
        await self.model_game.update_expired()

    @forever_reset_on_raise(sleep=300)
    async def worker_check_expired2(self):
        logging.debug('start worker_check_expired2')

        async for document in self.model_game.get_send_sync():
            game_id = document['_id']

            data = await self.bot_manager.bot_obj.session.send_request(
                url='https://crimewheel.com/api/update/{}'.format(game_id),
                data={
                    'magic_data': json.dumps(document, cls=LazyJSONEncoder),
                },
                is_post=True,
                is_json=True,
                timeout=10,
            )
            if data['status']:
                await self.model_game.update_send_sync(game_id)
            # todo message

    async def _sell_bitskins(self):
        dict_assets_in_eq = await self.bot_manager.get_my_backpack(get_sent=False, get_mapped=1, by_group=2)
        list_assets_in_eq = set(dict_assets_in_eq.keys())

        list_assets_to_sell = set()
        async for document in self.model_game.collection.find({
            'sell_trade_data.items_their_assets.my_asset_id': {'$in': list(list_assets_in_eq)}
        }, {
            'sell_trade_data': 1,
        }):
            for d in document['sell_trade_data']['items_their_assets']:
                if d['my_asset_id'] in list_assets_in_eq:
                    list_assets_to_sell.add((d['my_asset_id'], d['market_hash_name']))

        items = []
        for asset_id, weapon_name in list_assets_to_sell:
            price = self._db_price.get(weapon_name)
            if not price:
                continue
            items.append((str(asset_id), str(round(float(str(price)), 2)),))

        if items:
            data = await self.bitskins.sell_items(items[0:50])
            logging.debug('bit response for sell: {}'.format(data))
            logging.debug('bit response for sell: {}'.format(items[0:50]))

            for trade_token in data.get('data', {}).get('trade_tokens', []):
                self._db_sale_tokens.add(trade_token)

        logging.debug('items for sell: {}'.format(list_assets_to_sell))

    @forever_reset_on_raise(sleep=290)
    async def worker_sell_bitskins(self):
        await asyncio.sleep(15)
        # to_recheck = []
        # async for document in self.model_game.collection.find({
        #     'sell_trade_data.status': 5
        # }, {
        #     'sell_unique_id': 1,
        #     'sell_timestamp': 1,
        # }):
        #     to_recheck.append(document['sell_unique_id'])
        #     await self.bot_manager.model_api.collection.update_one({
        #         'request_uid': document['sell_unique_id'],
        #         'response_data.status': 2,
        #     }, {
        #         '$set': {
        #             'status': 1,
        #             'when_expire_at': datetime.datetime.now() + datetime.timedelta(minutes=30),
        #         }
        #     })
        #     logging.debug('update!')
        #
        # logging.debug('start rechek: {}'.format(to_recheck))

        logging.debug('start worker_sell_bitskins')
        await self._sell_bitskins()

    @forever_reset_on_raise(sleep=4)
    async def worker_sell_trade(self):
        async for document in self.model_game.get_sell_to_send():
            await self.get_sell_and_send(document['_id'])

    @forever_reset_on_raise(sleep=4)
    async def worker_winner_trade(self):
        async for document in self.model_game.get_winner_to_send():
            await self.get_winner_and_send(document['_id'])

    @forever_reset_on_raise(sleep=5)
    async def worker_buy_trade(self):
        async for document in self.model_game.get_trade_to_buy():
            await self.get_trade_and_buy(document['_id'])

    @forever_reset_on_raise(sleep=310)
    async def worker_check_pending_inventory(self):
        # co ok 5min sprawdza bitskins i probuje wyplacic skiny
        logging.debug('start worker_check_pending_inventory')
        await asyncio.sleep(10)
        await self.bitskins.withdraw_all_items_in_inventory()

    @forever_reset_on_raise(sleep=4)
    async def worker_event(self):
        while True:
            (channel, data) = await self.bot_manager.event_queue.get()
            if channel == 'trade_data':
                logging.info('on worker_event, data={}'.format(data))

                if data['data']['type'] == TradeModel.TYPE_RECEIVED:
                    if await self.incoming_on_trade_data(data):
                        await self.bot_manager.task_w4_set_accepted(event_id=data['event_id'])
                elif data['data']['type'] == TradeModel.TYPE_SEND:
                    if await self.sent_on_trade_data(data):
                        await self.bot_manager.task_w4_set_accepted(event_id=data['event_id'])

    async def get_user_by_id(self, steam_id: str, check_api: bool = False) -> dict:
        logging.debug('start get_user_profile_info for: {}'.format(steam_id))

        if check_api:
            try:
                user_info = await self.bot_manager.bot_obj.session.send_request(
                    url='https://crimewheel.com/api/user/{}'.format(steam_id),
                    is_post=False,
                    is_json=True,
                    timeout=10,
                )
            except asyncio.TimeoutError:
                raise ErrorMessage('api timeout response')

            status = user_info.pop('status')
            if status is None:
                raise ErrorMessage('api invalid response')

            if not status:
                raise ErrorMessage(user_info['message'])

            self.db_users[steam_id] = user_info
            return user_info
        else:
            user_info = self.db_users.get(steam_id)
            if not user_info:
                return await self.get_user_by_id(steam_id, check_api=True)

            return user_info

    async def send_winner_trade(self, game_id: int, winner_steam_id: str, trade_message: str, list_assets: List[int]):
        request_uid = str(uuid.uuid4())
        user_data = await self.get_user_by_id(winner_steam_id, check_api=True)

        # TODO transaction -.-
        res = await self.model_game.update_winner_request(game_id, request_uid)
        if res.modified_count == 0:
            # todo alert to admin - wtf?
            logging.critical('send_winner_trade, game_id={}, res.modified_count == 0'.format(game_id))
            return

        await self.bot_manager.task_w4_send_trade(
            request_uid=request_uid,
            trade_partner=SteamIdParser(winner_steam_id).as_account(),
            trade_token=user_data['token'],
            items={
                'my': list_assets,
                'their': [],
            },
            trade_message='} ' + trade_message.format(
                game_id=game_id,
                secret_id=request_uid
            ),
            expire=3600,  # 60*60=60min
        )
        # self.emit_message(winner_steam_id, -1, '[800] You win trade was add to queue.')  # FIXME MESSAGE

    async def send_sell_trade(self, game_id: int, winner_steam_id: str, trade_message: str, list_their_assets: List[int]):
        request_uid = str(uuid.uuid4())
        user_data = await self.get_user_by_id(winner_steam_id, check_api=True)

        # TODO transaction -.-
        res = await self.model_game.update_sell_request(game_id, request_uid)
        if res.modified_count == 0:
            # todo alert to admin - wtf?
            logging.critical('send_sell_trade, game_id={}, res.modified_count == 0'.format(game_id))
            return

        await self.bot_manager.task_w4_send_trade(
            request_uid=request_uid,
            trade_partner=SteamIdParser(winner_steam_id).as_account(),
            trade_token=user_data['token'],
            items={
                'my': [],
                'their': list_their_assets,
            },
            trade_message='] ' + trade_message.format(
                game_id=game_id,
                secret_id=request_uid
            ),
            expire=300,  # 5*60=5min
        )
        # self.emit_message(winner_steam_id, -1, '[800] You win trade was add to queue.')  # FIXME MESSAGE

    async def _get_winner_and_send(self, game_id: int):
        logging.info('start _get_winner_and_send, game_id={}'.format(game_id))

        document = await self.model_game.get_by_game_id(game_id)  # to moze chwile trwac

        game_id = document['_id']
        steam_id = document['steam_id']
        trade_message = document['winner_trade_message']
        items = document['buy_trade_data']['items_their_assets']
        is_all_set = all(item['my_asset_id'] is not None for item in items)

        if not is_all_set:
            # nie wszystkie itemy maja ustawiony asset id
            # todo emit do user ze steam jest opozniony
            logging.info('end _get_winner_and_send, game_id={}, not is_all_set'.format(game_id))
            return

        list_winner_assets = list(map(
            lambda o: o['my_asset_id'],
            items
        ))
        if not list_winner_assets:
            # FIXME nigdy nie powinno, bo kazdy powinien cos dostac!
            logging.info('end _get_winner_and_send, game_id={}, trades={}, not list_winner_assets'.format(game_id, items))
            return

        await self.send_winner_trade(game_id, steam_id, trade_message, list_winner_assets)
        logging.info('end _get_winner_and_send, game_id={}'.format(game_id))

    async def get_winner_and_send(self, game_id: int):
        if game_id in self._lock_game_in_winner:
            return

        try:
            await self._get_winner_and_send(game_id)
        except Exception as e:
            logging.critical('get_winner_and_send exception: {}'.format(traceback.format_exc()))
        finally:
            try:
                self._lock_game_in_winner.remove(game_id)
            except KeyError:
                pass

    async def _get_sell_and_send(self, game_id: int):
        logging.info('start _get_sell_and_send, game_id={}'.format(game_id))

        document = await self.model_game.get_by_game_id(game_id)  # to moze chwile trwac

        game_id = document['_id']
        steam_id = document['steam_id']
        trade_message = document['sell_trade_message']
        list_their_assets = document['sell_assets_items']

        if not list_their_assets:
            # FIXME nigdy nie powinno, bo kazdy powinien cos zabrac
            logging.info('end _get_sell_and_send, game_id={}, items={}, no list_their_assets'.format(game_id, list_their_assets))
            return

        await self.send_sell_trade(game_id, steam_id, trade_message, list_their_assets)
        logging.info('end _get_sell_and_send, game_id={}'.format(game_id))

    async def get_sell_and_send(self, game_id: int):
        if game_id in self._lock_game_in_winner:
            return

        try:
            await self._get_sell_and_send(game_id)
        except Exception as e:
            logging.critical('get_sell_and_send exception: {}'.format(traceback.format_exc()))
        finally:
            try:
                self._lock_game_in_winner.remove(game_id)
            except KeyError:
                pass

    async def _get_trade_and_buy(self, game_id: int):
        logging.info('start _get_trade_and_buy, game_id={}'.format(game_id))

        document = await self.model_game.get_by_game_id(game_id)  # to moze chwile trwac

        game_id = document['_id']
        market_hash_name = document['market_hash_name']

        try:
            bitskins_trade_token = await self.bitskins.buy_item_by_name_and_withdraw(market_hash_name)
            await self.model_game.update_trade_was_bought(game_id, bitskins_trade_token)

        except AssertionError as e:
            logging.debug('_get_trade_and_buy fail buy, game_id={}, mes={}'.format(game_id, str(e)))
            await self.model_game.update_trade_next_buy_check(game_id, str(e))

        except Exception as e:
            logging.critical('exception on buying {}'.format(traceback.format_exc()))
            await self.model_game.update_trade_next_buy_check(game_id, str(e))

        logging.info('end _get_trade_and_buy, game_id={}'.format(game_id))

    async def get_trade_and_buy(self, game_id: int):
        if game_id in self._lock_game_in_winner:
            return

        try:
            await self._get_trade_and_buy(game_id)
        except Exception as e:
            logging.critical('get_trade_and_buy exception: {}'.format(traceback.format_exc()))
        finally:
            try:
                self._lock_game_in_winner.remove(game_id)
            except KeyError:
                pass

    ##### przychodzace trade
    async def incoming_on_trade_data(self, all_data: dict) -> bool:
        '''
        'event_id': str(document['_id']),
        'event_created_at': document['created_at'].timestamp(),
        'request_uid': str(document['request_uid']),
        'timestamp': time.time(),
        'data': document['response_data'],

                'type': trade_document['type'],
                'trade_steam_id64': trade_document.get('trade_steam_id64'),

                'trade_id': trade_document['trade_id'],
                'items': trade_document['items'],

                'is_check_their_assets': trade_document['is_check_their_assets'],
                'items_their_in_my_eq': {str(data['their_asset_id']): data['my_asset_id'] for data in trade_document['items_their_assets']},

                'items_their_assets': trade_document['items_their_assets'],
                'items_my_assets': trade_document['items_my_assets'],

                'status': trade_document['status'],
                'send_error': trade_document['send_error'],

                'created_at': trade_document['created_at'],
                'expire_at': trade_document['expire_at'],
                'send_at': trade_document['send_at'],
                'accepted_at': trade_document['accepted_at'],
                'accepted_pending_at': trade_document['accepted_pending_at'],
                'error_at': trade_document['error_at'],
        '''
        trade_data = all_data['data']

        logging.debug('on_trade_data: data={}'.format(trade_data))

        steam_id = str(trade_data['trade_steam_id64'])
        trade_message = str(trade_data['trade_message'])
        trade_id = int(trade_data['trade_id'])
        items = trade_data['items_their_assets']
        items_from_bot = trade_data['items_my_assets']
        event_created_at = all_data['event_created_at']

        # nie chcemy dodawac do gry pustej listy itemow lub itemow od admina?
        if not items or items_from_bot:
            logging.debug('on_trade_data: not items or items_from_bot: data={}'.format(trade_data))
            return True

        # BitSkins Trade Token: fd362f775e94d20c, Trade ID: 6fa6a5be6073fb69
        match = re.search(
            r'^BitSkins Trade Token: (?P<trade_token>[A-Za-z0-9]+), Trade ID: (?P<trade_id>[A-Za-z0-9]+)$',
            trade_message
        )
        if not match:
            logging.debug('on_trade_data: token not match: trade_message={}'.format(trade_message))
            return True

        data_match = match.groupdict()

        bitskins_trade_token = data_match['trade_token']  # this
        bitskins_trade_id = data_match['trade_id']

        # todo accept bitskins sell self._db_sale_tokens

        res = await self.model_game.update_buy_trade_uid(
            bitskins_trade_token,
            bitskins_trade_id,
            event_created_at,
            trade_id,
            trade_data,
        )
        if res.modified_count == 0:  # bedzie wtedy gdy sprzedajemy swoj item
            # todo alert to admin - wtf?
            logging.critical('stop incoming_on_trade_data, all_data={}, res.modified_count == 0'.format(all_data))
            return True

        return True

    def emit(self, channel: str, data: dict, timeout=None) -> None:
        logging.debug('emit: channel={}, data={}'.format(channel, data))
        self.bot_manager.send_websocket_channel(channel, data, timeout=timeout)

    def emit_to(self, group: str, channel: str, data: dict) -> None:
        logging.debug('emit_to: channel={}, data={}'.format(channel, data))
        self.bot_manager.send_websocket_channel(channel, {
            'data': data,
            'group': group,
        })

    ########################################################################
    async def incoming_trade_cancel(self, trade_data: dict, message: str):
        await self.bot_manager.model_trade.init_receive(
            trade_id=trade_data['trade_id'],  # todo unique
            trade_partner=SteamIdParser(trade_data['steam_id64']).as_account(),
            trade_token='',
            items_my_assets=trade_data['items_my_assets'],
            items_their_assets=trade_data['items_their_assets'],
            trade_message=trade_data['message'],
            request_uid=str(uuid.uuid4()),
            trade_to_state=self.bot_manager.model_trade.STATE_TO_CANCEL,
            send_error=message,
        )

    async def incoming_trade_accept(self, trade_data: dict):
        await self.bot_manager.model_trade.init_receive(
            trade_id=trade_data['trade_id'],  # todo unique
            trade_partner=SteamIdParser(trade_data['steam_id64']).as_account(),
            trade_token='',
            items_my_assets=trade_data['items_my_assets'],
            items_their_assets=trade_data['items_their_assets'],
            trade_message=trade_data['message'],
            request_uid=str(uuid.uuid4()),
            trade_to_state=self.bot_manager.model_trade.STATE_TO_ACCEPT,
            send_error=None,
        )

    async def on_trade_received(self, trade_id: int, trade_data: dict):
        try:
            await self._on_trade_received(trade_id, trade_data)
        except Exception as e:
            logging.critical('_on_trade_received exception: {}'.format(traceback.format_exc()))
        finally:
            try:
                self._trades_in_pre_queue.remove(trade_id)
            except KeyError:
                pass

    async def _on_trade_received(self, trade_id: int, trade_data: dict) -> None:
        logging.debug('_on_trade_received: trade_id={}, trade_data={}'.format(
            trade_id,
            trade_data
        ))

        trade_message = str(trade_data.get('message', ''))
        items_my_assets = trade_data.get('items_my_assets', [])  # ktore od bota chcemy
        items_their_assets = trade_data.get('items_their_assets', [])  # ktore dostajemy

        # todo accept bitskins sell self._db_sale_tokens
        # if items_my_assets:
        #     if str(trade_data['steam_id64']) in ADMINS_STEAM_ID:
        #         logging.debug('_on_trade_received: {}, data={}'.format("accepted by admin", trade_data))
        #         await self.trade_accept(trade_data, {}, {'token': 'admin'})
        #         # gdy ktos chce od bota itemy, to wtedy trzeba potwierdzic
        #         # await self.bot_obj.accept_mobile_by_trade_id(trade_id)
        #         return

        if items_my_assets:
            match = re.search(
                r'^BitSkins Trade Token: (?P<trade_token>[A-Za-z0-9]+), Trade ID: (?P<trade_id>[A-Za-z0-9]+)$',
                trade_message
            )
            if not match:
                logging.debug('_on_trade_received: {}'.format('items_my_assets'))
                await self.incoming_trade_cancel(trade_data, 'want my items')
                return

            data_match = match.groupdict()

            bitskins_trade_token = data_match['trade_token']  # this
            bitskins_trade_id = data_match['trade_id']

            if bitskins_trade_token in self._db_sale_tokens:
                try:
                    self._db_sale_tokens.remove(bitskins_trade_token)
                except:
                    pass

                logging.debug('_on_trade_received: {}'.format("function end"))
                await self.incoming_trade_accept(trade_data)
                return

            logging.debug('_on_trade_received: {}'.format('items_my_assets'))
            await self.incoming_trade_cancel(trade_data, 'want my items')
            return

        for item in items_their_assets:
            if item['app_id'] != 730:
                logging.debug('_on_trade_received: {}'.format("item['app_id'] != 730"))
                await self.incoming_trade_cancel(trade_data, 'invalid app id')
                return

        logging.debug('_on_trade_received: {}'.format("function end"))
        await self.incoming_trade_accept(trade_data)
        return

    # PUBLIC API to bot manager
    async def on_manager_receive_trade(self, trade_id: int, trade_data: dict):
        '''
        'class_id': item.get('classid', 0),
        'instance_id': item.get('instanceid', 0),
        'icon_url': desc.get('icon_url'),
        'icon_url_large': desc.get('icon_url_large'),
        'market_hash_name': desc['market_hash_name'],
        'name': desc['name'],
        'exterior': exterior[0] if exterior else None,
        'inspect': inspect,
        'price': price,
        'stickers': self._parse_stickers_data(list_sticker_raw[0]) if list_sticker_raw else [],
        'asset_id': item_asset_id,

        'trade_id': int(trade_data['tradeofferid']),
        'steam_id64': SteamIdParser(trade_data['accountid_other']).as_64(),
        'message': trade_data.get('message', ''),

        'items_my_assets': items_my_assets,
        'items_their_assets': items_their_assets,
        '''
        # pamietam ze to szybko ma sie wykonac :)
        if trade_id not in self._trades_in_pre_queue:
            self._trades_in_pre_queue.add(trade_id)
            asyncio.ensure_future(self.on_trade_received(trade_id, trade_data))
