import requests
import random


class SteamTimeout(Exception):
    pass


class SteamHelper(object):
    def get_random_key(self):
        from .settings import STEAM_HELPER_KEYS
        return random.choice(STEAM_HELPER_KEYS)

    def __init__(self, steam_id):
        self.steam_id = steam_id
        self.api_key = self.get_random_key()

    def get_user_games(self):
        try:
            return requests.get('http://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/', params={
                'key': self.api_key,
                'steamid': str(self.steam_id),
                'format': 'json',
            }, timeout=5).json().get('response', {})
        except:
            raise SteamTimeout()

    def get_user_info(self):
        try:
            data = requests.get('http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/', params={
                'key': self.api_key,
                'steamids': str(self.steam_id),
                'format': 'json',
            }, timeout=5).json().get('response', {}).get('players', [])
            return data[0] if data else {}
        except:
            raise SteamTimeout()

    def have_csgo(self):
        data = self.get_user_games()
        for game in data.get('games', {}):
            if int(game.get('appid', 0)) == 730:
                return True

        return False
