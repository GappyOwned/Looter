from django.apps import AppConfig


class JackpotConfig(AppConfig):
    name = 'upgrader'
