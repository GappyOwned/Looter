import json
from django.db import models


class Game(models.Model):
    STATUS_TRADE_TO_SEND = 1  # trade z itemem do pobrania od typa
    STATUS_TRADE_REQUEST = 2
    STATUS_TRADE_SENT = 3

    STATUS_TO_BUY = 4  # item do kupienia na bitskins
    STATUS_WAIT_TRADE = 5  # item kupiony ale czekamy na trade
    STATUS_TO_SEND = 6  # trade, item gotowy do wysylki
    STATUS_SENT = 7  # trade wyslany do ziomka
    STATUS_ACCEPTED = 8  # trade zaakceptowany
    STATUS_CANCEL = 9  # czas na wysylke minal, lub za duzo bledow

    user = models.ForeignKey('user.User')

    trade_asset_id = models.BigIntegerField()
    trade_weapon = models.CharField(max_length=255)
    trade_img = models.CharField(max_length=1024)
    trade_price = models.DecimalField(decimal_places=2, max_digits=9)

    win_weapon = models.CharField(max_length=255)
    win_img = models.CharField(max_length=1024)
    win_price = models.DecimalField(decimal_places=2, max_digits=9)

    message = models.TextField(default='')
    status = models.IntegerField(default=0, choices=[
        (0, 'Unknown status'),
        (STATUS_TRADE_TO_SEND, 'Trade to Send'),
        (STATUS_TRADE_REQUEST, 'Trade to Send'),
        (STATUS_TRADE_SENT, 'Trade was sent'),
        (STATUS_TO_BUY, 'Trade accepted'),
        (STATUS_WAIT_TRADE, 'Trade accepted'),
        (STATUS_TO_SEND, 'Trade accepted'),
        (STATUS_SENT, 'Trade was sent'),
        (STATUS_ACCEPTED, 'Game accepted'),
        (STATUS_CANCEL, 'Game aborted'),
    ])

    data = models.TextField()

    created_at = models.DateTimeField(auto_now_add=True)

    def get_win_weapon(self):
        if self.status in [
            self.STATUS_TO_BUY,
            self.STATUS_WAIT_TRADE,
            self.STATUS_TO_SEND,
            self.STATUS_SENT,
            self.STATUS_ACCEPTED,
        ]:
            if not self.win_weapon:
                return 'Nothing'
            return '{} (${})'.format(self.win_weapon, self.win_price)

        return ''

    def set_data(self, data):
        self.data = json.dumps(data)

    def get_data(self):
        return json.loads(self.data)

    def get_messages(self):
        try:
            d = json.load(self.message)
        except:
            return []

        r = []
        if d.get('sell_error'):
            r.append(d.get('sell_error'))

        if d.get('winner_error'):
            r.append(d.get('winner_error'))

        return d
