from django.conf.urls import url
from .views import (
    IndexView,
    SettingsView,
    FAQView,
    TOSView,
    SupportView,
    HistoryView,

    ApiGetEqView,
    ApiMakeGameView,
    ApiRunGameView,
    ApiUserChatView,
)


urlpatterns = [
    url(r'settings$', SettingsView.as_view(), name='settings'),
    url(r'faq$', FAQView.as_view(), name='faq'),
    url(r'tos$', TOSView.as_view(), name='tos'),
    url(r'support$', SupportView.as_view(), name='support'),
    url(r'history$', HistoryView.as_view(), name='history'),

    url(r'api/eq$', ApiGetEqView.as_view(), name='api-get-eq'),
    url(r'api/roller$', ApiMakeGameView.as_view(), name='api-make-game'),
    url(r'api/roll$', ApiRunGameView.as_view(), name='api-run-game'),
    url(r'api/chat', ApiUserChatView.as_view(), name='api-chat'),

    url(r'', IndexView.as_view(), name='index'),
]
