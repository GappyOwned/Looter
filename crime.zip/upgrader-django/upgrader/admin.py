from django.contrib import admin
# from .models import (
#     GameRound,
#     Deposit,
#     DepositItem,
# )
#
#
# @admin.register(GameRound)
# class AdminGameRound(admin.ModelAdmin):
#     list_display = ('round_num', 'round_hash', 'winner', 'chance', 'total_price', 'created_at',)
#     list_filter = ('round_num',)
#
#
# class DepositItemAdminInline(admin.TabularInline):
#     model = DepositItem
#     extra = 1
#
#
# @admin.register(Deposit)
# class AdminDeposit(admin.ModelAdmin):
#     inlines = (DepositItemAdminInline,)
#     list_display = ('user', 'full_price', 'created_at',)
