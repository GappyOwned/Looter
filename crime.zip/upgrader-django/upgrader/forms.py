import re
from django import forms
from django.core.exceptions import ValidationError


class SettingForm(forms.Form):
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        super().__init__(*args, **kwargs)

    trade_url = forms.CharField(label='You trade url', required=True)

    def clean_trade_url(self):
        trade_url = self.cleaned_data['trade_url']
        match = re.search(
            r'^https?://steamcommunity\.com/tradeoffer/new/\?partner=([1-9][0-9]{0,12})&token=([a-zA-Z0-9_-]{5,15})$',
            trade_url
        )

        if not match:
            raise ValidationError('Please enter valid trade url')

        account_id = int(match.group(1))
        token = match.group(2)

        if (76561197960265728 + account_id) != int(self.user.steam_id):
            raise ValidationError('This is not your trade url')

        return trade_url
