import datetime
import time
import json
import logging
import requests
from decimal import Decimal
from django.core.cache import cache

from django.core.exceptions import ValidationError, PermissionDenied
from django.http import Http404
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import TemplateView, ListView, View

from django.contrib.auth.mixins import LoginRequiredMixin
from ipware.ip import get_ip

from upgrader.forms import SettingForm
from upgrader.models import Game
from user.models import User


def send_to_socket(target: str, channel: str, data: dict):
    t = requests.post('http://127.0.0.1:8001/api/v1/emit_to/{}/{}'.format(target, channel), data=json.dumps(data), headers={
        'Content-Type': 'application/json',
    }, timeout=2)
    return t.text == 'OK'


class AdminRequiredMixin(LoginRequiredMixin):
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_superuser:
            return super().dispatch(request, *args, **kwargs)
        raise PermissionDenied('no access')


class ApiUserChatView(AdminRequiredMixin, View):
    def post(self, request, *args, **kwargs):
        message_id = request.POST.get('message_id')
        if message_id:
            send_to_socket('internal', 'remove_msg', {
                'message_id': message_id,
            })
        else:
            user_id = request.POST.get('user_id')
            is_remove_all = bool(int(request.POST.get('remove_all', '0')))
            try:
                user = User.objects.get(pk=user_id)
            except User.DoesNotExist:
                raise Http404('not found')

            user.chat_ban = 1
            user.save()

            send_to_socket('internal', 'user_ban', {
                'user_id': user.pk,
                'is_remove_all': is_remove_all,
            })

        return JsonResponse({
            'status': 1,
        }, content_type="application/json")


class ApiGetEqView(LoginRequiredMixin, View):
    def get_items(self):
        r = requests.post('http://51.255.85.92:10052/api/v1/request/get_their_backpack', data=json.dumps({
            'steam_id': str(self.request.user.steam_id),
            'min_price': '0.05',
            'by_group': 2,
        }), headers={
            'Content-Type': 'application/json',
        }, timeout=30)

        if r.status_code == 200:
            return r.json()['data']
        elif r.status_code == 500:
            raise AssertionError(r.text)

        raise AssertionError('Can\'t load eq')

    def post(self, request, *args, **kwargs):
        try:
            items = self.get_items()
            return JsonResponse({
                'items': items,
                'status': 1,
                'message': 'OK',
            }, content_type="application/json")
        except AssertionError as e:
            return JsonResponse({
                'status': 0,
                'message': str(e),
            }, content_type="application/json")


class ApiMakeGameView(LoginRequiredMixin, View):
    def get_data(self, asset_id: int):
        r = requests.post('http://51.255.85.92:10052/api/v1/request/get_roller', data=json.dumps({
            'steam_id': str(self.request.user.steam_id),
            'asset_id': str(asset_id),
            'tickets': [
                # real_percent, real_mnoznik, fake_percent
                ['20', '2', '40'],  # 2x
                ['24.5', '0.5', '25'],  # 0.5x
                ['0.5', '6', '15'],  # 6x
                ['55', '0', '20'],  # 0x
            ],
        }), headers={
            'Content-Type': 'application/json',
        }, timeout=30)

        if r.status_code == 200:
            return r.json()
        elif r.status_code == 500:
            raise AssertionError(r.text)

        raise AssertionError('Can\'t make roller')

    def post(self, request, *args, **kwargs):
        try:
            asset_id = int(request.POST.get('asset_id'))
        except:
            return JsonResponse({
                'status': 0,
                'message': 'Why hacking :(?',
            }, content_type="application/json")

        try:
            data = self.get_data(asset_id)
            cache.set(data['unique_id'], data, 600)  # 10 min

            l_r = []
            for d in data['list_weapons']:
                l_r.append({
                    'img': d['img'],
                    'market_hash_name': d['market_hash_name'],
                    'price': str(d['price']),
                    'percent': d['percent'],
                })

            return JsonResponse({
                'data': {
                    'list_weapons': l_r,
                    'unique_id': data['unique_id'],
                },
                'status': 1,
                'message': 'OK',
            }, content_type="application/json")
        except AssertionError as e:
            return JsonResponse({
                'status': 0,
                'message': str(e),
            }, content_type="application/json")


class ApiRunGameView(LoginRequiredMixin, View):
    def make_trade(self, game_id: int, asset_id: int, win_market_hash_name: str, extend_data: dict):
        r = requests.post('http://51.255.85.92:10052/api/v1/request/make_game', data=json.dumps({
            "game_id": game_id,
            "steam_id": str(self.request.user.steam_id),
            "assets_items": [str(asset_id)],
            "market_hash_name": win_market_hash_name,
            "sell_trade_message": "Your deposit on CrimeWheel!",
            "winner_trade_message": "Congratulations! CrimeWheel",
            "when_expire": int(time.time()) + (24 * 60 * 60),  # +1d
            "extend_data": extend_data,
        }), headers={
            'Content-Type': 'application/json',
        }, timeout=30)

        if r.status_code == 200:
            return r.json()
        elif r.status_code == 500:
            raise AssertionError(r.text)

        raise AssertionError('Can\'t make roller')

    def post(self, request, *args, **kwargs):
        try:
            unique_id = request.POST.get('unique_id')
        except:
            return JsonResponse({
                'status': 0,
                'message': 'Session expired, refresh site!',
            }, content_type="application/json")

        if not request.user.is_configured():
            return JsonResponse({
                'status': 2,
                'message': 'You need set trade url!',
            }, content_type="application/json")

        data = cache.get(unique_id)
        if data is None:
            return JsonResponse({
                'status': 0,
                'message': 'Session expired, refresh site!',
            }, content_type="application/json")

        cache.delete(unique_id)

        if not data['can_win_buy']:
            return JsonResponse({
                'status': 0,
                'message': 'Please contact with support!',
            }, content_type="application/json")

        game = Game()
        game.user = self.request.user

        if data['weapon_user']:
            game.trade_asset_id = data['weapon_user']['assets'][0]
            game.trade_weapon = data['weapon_user']['market_hash_name']
            game.trade_img = 'https://steamcommunity-a.akamaihd.net/economy/image/{}'.format(
                data['weapon_user']['icon_url'] or data['weapon_user']['icon_url_large'],
            )
            game.trade_price = Decimal(data['weapon_user']['price'])
        else:
            game.trade_asset_id = 0
            game.trade_weapon = ''
            game.trade_img = ''
            game.trade_price = Decimal(0)

        game.win_weapon = data['weapon_win']['market_hash_name']
        game.win_img = data['weapon_win']['img']
        game.win_price = Decimal(str(data['weapon_win']['price']))

        game.set_data(data)
        game.save()

        self.make_trade(
            game_id=game.id,
            asset_id=game.trade_asset_id,
            win_market_hash_name=game.win_weapon,
            extend_data=data,
        )

        return JsonResponse({
            'status': 1,
            'message': 'Trade will soon send to you! Then roll will spin!',
        }, content_type="application/json")


class IndexView(TemplateView):
    template_name = 'index.html'

    def get_context_data(self, **kwargs):
        return super().get_context_data(**kwargs)


class SettingsView(LoginRequiredMixin, TemplateView):
    def post(self, request, *args, **kwargs):
        user = request.user

        form = SettingForm(self.request.POST or None, initial={
            'trade_url': user.trade_url,
        }, user=user)
        if form.is_valid():
            trade_url = form.cleaned_data['trade_url']

            user.set_trade_url(trade_url)
            user.save()

            return JsonResponse({
                'status': 1,
                'message': 'Settings was saved!',
            }, content_type="application/json")
        else:
            return JsonResponse({
                'status': 0,
                'message': 'Invalid data in settings!',
            }, content_type="application/json")


class FAQView(TemplateView):
    template_name = 'faq.html'


class TOSView(TemplateView):
    template_name = 'tos.html'


class SupportView(LoginRequiredMixin, TemplateView):
    template_name = 'support.html'


class HistoryView(LoginRequiredMixin, TemplateView):
    template_name = 'history.html'

    def get_context_data(self, **kwargs):
        kwargs['games'] = Game.objects.filter(user=self.request.user).order_by('-created_at')
        return super().get_context_data(**kwargs)


# admin
class ApiUserInfo(View):
    def get(self, request, *args, **kwargs):
        ip = get_ip(request)
        if ip not in [
            '127.0.0.1',
            '51.255.85.92',
            '46.238.228.238',
            '80.241.222.106',
        ]:
            return JsonResponse({
                'status': False,
                'message': 'Access denied.',
            })

        steam_id = kwargs.get('steam_id')
        try:
            user = User.objects.get(steam_id=steam_id)
        except User.DoesNotExist:
            user = None

        if not user:
            return JsonResponse({
                'status': False,
                'message': 'Please login on site.',
            })

        if user.game_ban:
            return JsonResponse({
                'status': False,
                'message': 'Have game ban.',
            })

        trade_parsed = user.get_trade_url_striped()
        if trade_parsed is None:
            return JsonResponse({
                'status': False,
                'message': 'Don\'t have trade url.',
            })
        steam_id_user, trade_token = trade_parsed

        return JsonResponse({
            'status': True,
            'trade_link': user.trade_url,
            'username': user.persona_name,
            'avatar': user.avatar,
            'token': trade_token,
        })


# admin
class ApiUpdateInfo(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        ip = get_ip(request)
        if ip not in [
            '127.0.0.1',
            '51.255.85.92',
            '46.238.228.238',
            '80.241.222.106',
        ]:
            return JsonResponse({
                'status': False,
                'message': 'Access denied.',
            })

        game_id = kwargs.get('game_id')
        try:
            game = Game.objects.get(id=game_id)
        except Game.DoesNotExist:
            return JsonResponse({
                'status': False,
                'message': 'Game not found',
            })

        try:
            json_data = json.loads(request.POST.get('magic_data'))
        except:
            return JsonResponse({
                'status': False,
                'message': 'Json invalid',
            })

        sell_error = json_data['sell_trade_data']['send_error'] if json_data['sell_trade_data'] else None
        buy_error = json_data['buy_trade_data']['send_error'] if json_data['buy_trade_data'] else None
        winner_error = json_data['winner_trade_data']['send_error'] if json_data['winner_trade_data'] else None
        buy_error2 = json_data['buying_error']

        game.status = json_data['status']
        game.message = json.dumps({
            'sell_error': sell_error,
            'buy_error': buy_error,
            'winner_error': winner_error,
            'buy_error2': buy_error2,
        })
        game.save()

        return JsonResponse({
            'status': True,
            'game_id': int(game_id),
        })
