from django.conf import settings

STEAM_HELPER_KEYS = getattr(settings, 'STEAM_HELPER_KEYS', tuple())
