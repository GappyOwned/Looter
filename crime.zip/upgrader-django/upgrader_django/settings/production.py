from .base import *


# SECRET_KEY = get_env_variable('SECRET_KEY')

DEBUG = False
ALLOWED_HOSTS = [
    '127.0.0.1',
    'crimewheel.com',
]

STEAM_HELPER_KEYS = (
    'AB1E2E0189F9FBAB1CCFD8C234E03E2A',
)

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'USER': 'upgrader',
        'NAME': 'upgrader',
        'PASSWORD': '12qw',
        'HOST': '127.0.0.1',
        'PORT': '5432',
    },
}

SESSION_REDIS_PREFIX = 'session'  # 'session:<session_hash>'
SESSION_REDIS_HOST = '127.0.0.1'
SESSION_REDIS_PORT = 6379
SESSION_REDIS_DB = 2
CACHES = {
    'default': {
        'BACKEND': 'redis_cache.RedisCache',
        'LOCATION': '127.0.0.1:6379',
        'OPTIONS': {
            'DB': 3,
        }
    },
}
