from .base import *


# SECRET_KEY = get_env_variable('SECRET_KEY')

DEBUG = True
ALLOWED_HOSTS = [
    '127.0.0.1',
    'crimewheel.com',
]

STEAM_HELPER_KEYS = (
    'AB1E2E0189F9FBAB1CCFD8C234E03E2A',
)

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'USER': 'root',
        'NAME': 'jackpot',
        'PASSWORD': '12qw',
        'HOST': '192.168.88.207',
        'PORT': '53306',
    },
}

SESSION_REDIS_PREFIX = 'session'  # 'session:<session_hash>'
SESSION_REDIS_HOST = '192.168.88.207'
SESSION_REDIS_PORT = 56379
SESSION_REDIS_DB = 2
CACHES = {
    'default': {
        'BACKEND': 'redis_cache.RedisCache',
        'LOCATION': '192.168.88.207:6379',
        'OPTIONS': {
            'DB': 3,
        }
    },
}

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(module)s %(process)d %(thread)d %(message)s',
        },
        'standard': {
            'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        },
    },
    'handlers': {
        'mail_admins': {
            'level': 'WARNING',
            'class': 'django.utils.log.AdminEmailHandler',
            'include_html': True,
        },
        'console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'formatter': 'verbose',
        },
        'null': {
            'class': 'logging.NullHandler',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': False,
        },
        'django.request': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': False,
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'DEBUG'
    }
}