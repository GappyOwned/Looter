import sys
from os import environ
from os.path import join, abspath, dirname
from django.contrib import messages

from django.core.exceptions import ImproperlyConfigured
from django_jinja.builtins import DEFAULT_EXTENSIONS


def get_env_variable(key):
    try:
        return environ[key]
    except KeyError:
        raise ImproperlyConfigured('Set the {0} environment var'.format(key))


BASE_DIR = abspath(join(abspath(dirname(__file__)), '..', '..'))
SECRET_KEY = 'local_key'

DEBUG = False
ALLOWED_HOSTS = []

INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'django_jinja',
    'bootstrapform_jinja',

    'user',
    'upgrader',
)

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.locale.LocaleMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'user.middleware.SessionExtendMiddleware',
)

ROOT_URLCONF = 'upgrader_django.urls'

TEMPLATES = [
    # {
    #     'BACKEND': 'django.template.backends.django.DjangoTemplates',
    #     'DIRS': [],
    #     'APP_DIRS': True,
    #     'OPTIONS': {
    #         'context_processors': [
    #             'django.template.context_processors.debug',
    #             'django.template.context_processors.request',
    #             'django.contrib.auth.context_processors.auth',
    #             'django.contrib.messages.context_processors.messages',
    #         ],
    #     },
    # },
    {
        'BACKEND': 'django_jinja.backend.Jinja2',
        'APP_DIRS': True,
        'DIRS': [
            join(BASE_DIR, 'templates'),
        ],
        'OPTIONS': {
            "match_extension": ".html",
            "match_regex": r"^(?!admin/).*",
            'extensions': DEFAULT_EXTENSIONS + [
                # 'jdj_tags.extensions.DjangoStatic',
                # 'jdj_tags.extensions.DjangoI18n',
            ],
            'filters': {
            },
            'context_processors': [
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'upgrader_django.wsgi.application'

DATABASES = {}
STATIC_URL = '/static/'
STATICFILES_DIRS = (
    join(BASE_DIR, 'assets'),
)

STATIC_ROOT = join(BASE_DIR, 'static')  # python manage.py collectstatic
MEDIA_ROOT = join(BASE_DIR, 'media')

TIME_ZONE = 'Europe/Warsaw'

USE_I18N = False  # change to true
USE_L10N = False
USE_TZ = False

LOCALE_PATHS = (  # python manage.py makemessages
    join(BASE_DIR, 'locale'),
)

LANGUAGE_CODE = 'en'
LANGUAGES = [
  # ('pl', 'Polish'),
  ('en', 'English'),
]


LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(module)s %(process)d %(thread)d %(message)s',
        },
        'standard': {
            'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        },
    },
    'handlers': {
        'mail_admins': {
            'level': 'WARNING',
            'class': 'django.utils.log.AdminEmailHandler',
            'include_html': True,
        },
        'console': {
            'class': 'logging.StreamHandler',
            'stream': sys.stdout,
            'formatter': 'verbose',
        },
        'null': {
            'class': 'logging.NullHandler',
        },
    },
    'loggers': {
        'django.request': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'INFO'
    }
}

SESSION_IDLE_TIMEOUT = 30 * 60  # 30min
SESSION_SAVE_EVERY_REQUEST = True
SESSION_ENGINE = 'redis_sessions.session'


MESSAGE_TAGS = {
    messages.ERROR: 'danger'
}

AUTHENTICATION_BACKENDS = (
    'user.backends.SteamUserBackend',
)
AUTH_USER_MODEL = 'user.User'
LOGIN_REDIRECT_URL = '/'
LOGIN_URL = '/user/login/'
LOGOUT_URL = '/user/logout/'

# SECURE_PROXY_SSL_HEADER = ('HTTP_X_Forwarded_PROTO', 'https')
