
Instalacja
----------
`pip3 install -r requirements.txt`




Inicjalizacja db
----------------
`python3 manage.py migrate --settings=upgrader_django.settings.production`





Odpalanie serwera
-----------------
`python3 manage.py runserver 0.0.0.0:8000 --settings=upgrader_django.settings.production`











http://fgda.pl/post/3/jinja2-internationalization-in-django

pybabel extract -F babel.cfg -o messages.pot .
pybabel init -D django -i messages.pot -d locale -l pl
    # edit /locale/pl/LC_MESSAGES/django.po filling it with translations
    # then remove the fuzzy markers:    #, fuzzy ...
    # finally run this:

pybabel compile -D django -i locale/pl/LC_MESSAGES/django.po -d locale -l pl
pybabel compile -D django -i locale/en/LC_MESSAGES/django.po -d locale -l en


pybabel update -D django -i messages.pot -d locale -l en