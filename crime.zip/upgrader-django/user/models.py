from decimal import Decimal
from django.contrib.auth.models import AbstractUser, Group, Permission
from django.core.validators import RegexValidator, ValidationError, validate_email
from django.db.models.manager import EmptyManager
from django.db import models
import re


class User(models.Model):
    REQUIRED_FIELDS = tuple()
    USERNAME_FIELD = 'steam_id'

    steam_id = models.CharField(primary_key=True, max_length=18)

    persona_name = models.CharField(max_length=255)
    trade_url = models.URLField(max_length=255, null=True, blank=False, validators=[
        RegexValidator(r'^https?://steamcommunity\.com/tradeoffer/new/\?partner=([1-9][0-9]{0,12})&token=[a-zA-Z0-9_-]{5,15}$')
    ])

    avatar = models.CharField(max_length=255)
    role = models.IntegerField()

    chat_ban = models.IntegerField()
    game_ban = models.IntegerField()
    have_global = models.SmallIntegerField()

    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)
    last_login = models.DateTimeField(null=True, default=None)

    objects = models.Manager()

    def __str__(self):
        return '{} ({})'.format(self.persona_name, self.steam_id)

    def can_access_chat(self):
        if self.chat_ban:
            return False
        return True

    def is_configured(self):
        match = RegexValidator(r'^https?://steamcommunity\.com/tradeoffer/new/\?partner=([1-9][0-9]{0,12})&token=[a-zA-Z0-9_-]{5,15}$')
        try:
            match(self.trade_url)
            return True
        except:
            pass
        return False

    def set_trade_url(self, trade_url):
        match = re.search(
            r'^https?://steamcommunity\.com/tradeoffer/new/\?partner=([1-9][0-9]{0,12})&token=([a-zA-Z0-9_-]{5,15})$',
            trade_url
        )

        if not match:
            raise ValidationError('Please enter valid trade url')

        account_id = int(match.group(1))
        token = match.group(2)

        if (76561197960265728 + account_id) != int(self.steam_id):
            raise ValidationError('This is not your trade url')

        self.trade_url = trade_url

    def get_trade_url_striped(self):
        if not self.is_configured():
            return None

        match = re.search(
            r'^https?://steamcommunity\.com/tradeoffer/new/\?partner=([1-9][0-9]{0,12})&token=([a-zA-Z0-9_-]{5,15})$',
            self.trade_url
        )

        account_id = int(match.group(1))
        token = match.group(2)

        return int(self.steam_id), token

    def _is_staff(self):
        return self.role > 1

    def _is_superuser(self):
        return self.role == 3

    is_staff = property(_is_staff)
    is_superuser = property(_is_superuser)
    is_active = True
    _groups = EmptyManager(Group)
    _user_permissions = EmptyManager(Permission)

    def set_password(self, raw_password):
        pass

    def check_password(self, raw_password):
        return True

    def _get_groups(self):
        return self._groups
    groups = property(_get_groups)

    def _get_user_permissions(self):
        return self._user_permissions
    user_permissions = property(_get_user_permissions)

    def get_group_permissions(self, obj=None):
        return set()

    def get_all_permissions(self, obj=None):
        return []

    def has_perm(self, perm, obj=None):
        return True

    def has_perms(self, perm_list, obj=None):
        return True

    def has_module_perms(self, module):
        return True

    def _is_anonymous(self):
        return False
    is_anonymous = property(_is_anonymous)

    def _is_authenticated(self):
        return True
    is_authenticated = property(_is_authenticated)

    def get_username(self):
        return self.steam_id
