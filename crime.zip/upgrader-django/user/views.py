import logging

from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect
from django.contrib import messages
from django.views.generic import View, RedirectView
from django.core.urlresolvers import reverse, reverse_lazy
from django.contrib.auth import authenticate, login, logout

from openid.store import memstore, filestore
from openid.consumer import consumer
from openid.extensions import sreg

from .utils import JSONSafeSession, SteamLoginError


class LoginView(View):
    def get_store(self, data_path=None):
        if data_path:
            store = filestore.FileOpenIDStore(data_path)
        else:
            store = memstore.MemoryStore()
        return store

    def get_consumer(self, request, store=None):
        return consumer.Consumer(JSONSafeSession(request.session), store)

    def is_mode(self):
        return self.request.GET.get('openid.mode') == 'id_res'

    def do_register(self, steam_id):
        user = authenticate(steam_id=steam_id)
        logging.info('do_register: {}, {}'.format(steam_id, user))
        if user:
            login(self.request, user)
            messages.success(self.request, 'Successfully logged in as <strong>{}</strong>!'.format(user.persona_name))

    def get(self, request, *args, **kwargs):
        if self.is_mode():
            try:
                steam_id = self.do_steam_verify()
                logging.info('do_steam_verify ok: {}'.format(steam_id))
                self.do_register(steam_id)

                return HttpResponseRedirect(reverse('upgrader:index'))
            except SteamLoginError as e:
                logging.warning(e)
                messages.error(request, str(e))
                return HttpResponseRedirect(reverse('upgrader:index'))
        else:
            try:
                return self.do_steam_login()
            except SteamLoginError as e:
                logging.warning(e)
                messages.error(request, str(e))
                return HttpResponseRedirect(reverse('upgrader:index'))

    def do_steam_login(self):
        # First, make sure that the user entered something
        openid_url = 'https://steamcommunity.com/openid'
        oid_consumer = self.get_consumer(self.request)
        try:
            oid_request = oid_consumer.begin(openid_url)
        except consumer.DiscoveryFailure as e:
            logging.critical('Error in discovery: {}'.format(e))
            raise SteamLoginError('Verification failed.')
        else:
            if oid_request is None:
                raise SteamLoginError('Verification failed.')
            else:
                # Then, ask the library to begin the authorization.
                # Here we find out the identity server that will verify the
                # user's identity, and get a token that allows us to
                # communicate securely with the identity server.
                trust_root = self.base_url()
                return_to = self.build_url('user:login')

                sreg_request = sreg.SRegRequest()
                oid_request.addExtension(sreg_request)

                redirect_url = oid_request.redirectURL(trust_root, return_to)
                return HttpResponseRedirect(redirect_url)

    def do_steam_verify(self):
        request_args = dict((k, v) for k, v in self.request.GET.items())
        oid_consumer = self.get_consumer(self.request)

        # Ask the library to check the response that the server sent
        # us.  Status is a code indicating the response type. info is
        # either None or a string containing more information about
        # the return type.
        if not str(request_args.get('openid.op_endpoint')).startswith('https://steamcommunity.com/openid/'):
            raise SteamLoginError('Verification failed.')

        return_to = self.build_url('user:login')
        info = oid_consumer.complete(request_args, return_to)

        display_identifier = info.getDisplayIdentifier()
        if info.status == consumer.FAILURE and display_identifier:
            # In the case of failure, if info is non-None, it is the
            # URL that we were verifying. We include it in the error
            # message to help the user figure out what happened.
            logging.critical("Verification of {} failed: {}".format(display_identifier, info.message))
            raise SteamLoginError('Verification failed.')
        elif info.status == consumer.SUCCESS:
            try:
                steam_id = display_identifier.split('/')[-1]
                return steam_id
            except:
                raise SteamLoginError('Verification failed.')
        elif info.status == consumer.CANCEL:
            raise SteamLoginError('Verification failed.')
        elif info.status == consumer.SETUP_NEEDED:
            raise SteamLoginError('Verification failed.')
        else:
            # Either we don't understand the code or there is no
            # openid_url included with the error. Give a generic
            # failure message. The library should supply debug
            # information in a log.
            raise SteamLoginError('Verification failed.')

    def build_url(self, name_url):
        url = self.request.build_absolute_uri(reverse(name_url))
        return url

    def base_url(self):
        url = '{scheme}://{host}'.format(scheme=self.request.scheme, host=self.request.get_host())
        return url


class LogoutView(LoginRequiredMixin, RedirectView):
    url = reverse_lazy('upgrader:index')
    permanent = False

    def get(self, request, *args, **kwargs):
        logout(request)
        return super().get(request, *args, **kwargs)
