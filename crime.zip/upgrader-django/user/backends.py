import re

from django.contrib.auth.backends import ModelBackend
from django.core.exceptions import PermissionDenied
from django.utils.crypto import get_random_string

from upgrader.steam import SteamHelper, SteamTimeout
from .models import User
from .utils import SteamLoginError


class SteamUserBackend(ModelBackend):
    def authenticate(self, steam_id):
        try:
            user = User.objects.get(steam_id=steam_id)
        except User.DoesNotExist:
            user = User()
            user.steam_id = steam_id
            user.chat_ban = 0
            user.game_ban = 0
            user.role = 1

        api = SteamHelper(steam_id)
        try:
            user_info = api.get_user_info()
        except SteamTimeout:
            raise SteamLoginError('Error with Steam API. Please try again later.')

        if not user_info:
            raise SteamLoginError('Error with Steam. Please try again later.')

        # if int(user_info.get('personastate', 0)) == 0:
        #     raise SteamLoginError('You need to set your profile to public to use our site!')

        user.avatar = user_info['avatarfull']
        user.persona_name = self.parse_username(user_info['personaname'])
        user.have_global = api.have_csgo()
        user.save()

        return user

    def get_user_permissions(self, user_obj, obj=None):
        """
        Returns a set of permission strings the user `user_obj` has from their
        `user_permissions`.
        """
        return True

    def get_group_permissions(self, user_obj, obj=None):
        """
        Returns a set of permission strings the user `user_obj` has from the
        groups they belong.
        """
        return True

    def get_all_permissions(self, user_obj, obj=None):
        return set()

    def has_perm(self, user_obj, perm, obj=None):
        return True

    def has_module_perms(self, user_obj, app_label):
        """
        Returns True if user_obj has any permissions in the given app_label.
        """
        return True

    def parse_username(self, username):
        # usuwanie znacznikow html
        username = re.sub(r'[><&;]', '', username)

        # list_to_ban = list()
        # for match in re.findall(r'((?:[a-zA-Z0-9-]+)[^a-z0-9]+(?:one|com|pl|eu|bet|us|best|casino|gl|io|xyz|net|org|ru|gg|club))', username, re.IGNORECASE):
        #     if 'bets-go' in match.lower():
        #         continue
        #
        #     list_to_ban.append(match)
        #     username = username.replace(match, '')

        username = username.strip()
        return username if username else 'Unnamed'
