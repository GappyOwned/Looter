from .models import User


class SessionExtendMiddleware(object):
    def process_request(self, request):
        if not isinstance(request.user, User):
            return

        if request.user.is_authenticated:
            request.session['user_id'] = request.user.pk
            request.session['steam_id'] = request.user.steam_id
            request.session['username'] = request.user.persona_name
            request.session['avatar'] = request.user.avatar
            request.session['role'] = request.user.role
            request.session['can_access_chat'] = request.user.can_access_chat()
            request.session.save()
